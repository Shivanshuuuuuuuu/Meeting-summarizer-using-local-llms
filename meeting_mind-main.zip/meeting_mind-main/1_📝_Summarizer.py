"""
📝 Summarizer Page — The Core Product
=====================================
This page is the main data product: paste/upload a meeting transcript
and get a structured summary with decisions, action items, and more.

The Ollama LLM call here is the API-in-the-loop component.
Summaries are auto-saved to MongoDB for history & analytics.
"""

import time
import os
import streamlit as st

# Must be first Streamlit command
st.set_page_config(
    page_title="Summarizer — MeetingMind",
    page_icon="📝",
    layout="wide",
)

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from utils.ollama_client import (
    check_connection,
    get_available_models,
    summarize_transcript_stream,
)
from utils.text_processing import count_words, estimate_tokens, validate_input
from utils.export import to_markdown, to_plain_text
from utils.db_client import (
    check_mongo_connection,
    save_summary,
    save_feedback,
    log_usage,
)


# ── Shared Styles & Sidebar ─────────────────────────────────────────────
from utils.styles import inject_global_css
from utils.sidebar import render_sidebar

inject_global_css()
connected, _ = render_sidebar(show_connection=True)

# Page-specific: model selector in sidebar
with st.sidebar:
    if connected:
        models = get_available_models()
        selected_model = st.selectbox(
            "🤖 Model",
            models,
            index=0,
            help="Choose which Ollama model to use for summarization",
        )
    else:
        selected_model = "llama3.2"



# ── Page Header ─────────────────────────────────────────────────────────
st.markdown('<div class="page-header">📝 Meeting Summarizer</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="page-subtitle">'
    "Paste your meeting transcript or upload a text file. "
    "MeetingMind will extract decisions, action items, and key discussion points."
    "</div>",
    unsafe_allow_html=True,
)
st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)


# ── Input Section ───────────────────────────────────────────────────────
uploaded_file = None
transcript_text = ""

input_tab, upload_tab = st.tabs(["✍️  Paste Text", "📁  Upload File"])

with input_tab:
    # Load sample button
    sample_path = os.path.join(os.path.dirname(__file__), "..", "data", "sample_transcript.txt")

    col_sample, col_clear = st.columns([1, 1])
    with col_sample:
        load_sample = st.button("📄 Load Sample Transcript", use_container_width=True)
    with col_clear:
        clear_text = st.button("🗑️ Clear", use_container_width=True)

    # Handle sample loading
    if load_sample:
        try:
            with open(sample_path, "r", encoding="utf-8") as f:
                st.session_state["transcript_input"] = f.read()
        except FileNotFoundError:
            st.warning("Sample file not found.")

    if clear_text:
        st.session_state["transcript_input"] = ""

    transcript_text = st.text_area(
        "Meeting Transcript",
        value=st.session_state.get("transcript_input", ""),
        height=280,
        placeholder="Paste your meeting notes or transcript here...\n\nExample:\nSarah (PM): Let's discuss the Q3 launch timeline...\nJames (Engineering): The backend migration is 90% complete...",
        key="transcript_input",
        label_visibility="collapsed",
    )

with upload_tab:
    uploaded_file = st.file_uploader(
        "Upload a meeting transcript (.txt file)",
        type=["txt"],
        help="Upload a plain text file containing your meeting notes or transcript.",
    )
    if uploaded_file:
        transcript_text = uploaded_file.read().decode("utf-8")
        st.text_area(
            "File Preview",
            value=transcript_text[:2000] + ("..." if len(transcript_text) > 2000 else ""),
            height=200,
            disabled=True,
        )


# ── Metrics Bar ─────────────────────────────────────────────────────────
if transcript_text and transcript_text.strip():
    words = count_words(transcript_text)
    tokens = estimate_tokens(transcript_text)
    st.markdown(
        f"""
        <div class="metric-bar">
            <div class="metric-item">📝 Words: <span class="metric-value">{words:,}</span></div>
            <div class="metric-item">🔤 Tokens: <span class="metric-value">~{tokens:,}</span></div>
            <div class="metric-item">🤖 Model: <span class="metric-value">{selected_model}</span></div>
            <div class="metric-item">💰 Cost: <span class="metric-value" style="color:#10B981;">₹0 (local)</span></div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ── Summarize Button ───────────────────────────────────────────────────
st.markdown("")

summarize_clicked = st.button(
    "🚀  Summarize Meeting",
    use_container_width=True,
    type="primary",
    disabled=not connected,
)

if summarize_clicked:
    # Validate input
    is_valid, validation_msg = validate_input(transcript_text)
    
    if not is_valid:
        st.warning(validation_msg)
    else:
        # Warn if transcript may exceed model context window
        token_count = estimate_tokens(transcript_text)
        word_count = count_words(transcript_text)
        if token_count > 3500:
            st.warning(
                f"⚠️ This transcript is ~{token_count:,} tokens. "
                "Llama 3.2 (3B) may truncate or produce lower-quality results for very long inputs. "
                "Consider shortening it for best results."
            )

        st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)
        st.markdown('<div class="result-header">📊 Summary Results</div>', unsafe_allow_html=True)
        
        # Timer
        start_time = time.time()
        
        # Stream the response
        with st.spinner("🧠 Analyzing transcript with Ollama..."):
            try:
                result_container = st.empty()
                full_response = ""
                
                for chunk in summarize_transcript_stream(transcript_text, selected_model):
                    full_response += chunk
                    result_container.markdown(full_response)
                
                elapsed = time.time() - start_time
                
                # Store result in session state
                st.session_state["last_summary"] = full_response
                st.session_state["last_elapsed"] = elapsed
                st.session_state["last_source"] = (
                    uploaded_file.name if uploaded_file is not None else "Pasted Text"
                )

                # ── Auto-save to MongoDB ────────────────────────────────
                try:
                    mongo_ok, _ = check_mongo_connection()
                    if mongo_ok:
                        doc_id = save_summary(
                            transcript=transcript_text,
                            summary=full_response,
                            model=selected_model,
                            source=st.session_state["last_source"],
                            elapsed=elapsed,
                            word_count=word_count,
                            token_count=token_count,
                        )
                        st.session_state["last_summary_id"] = doc_id

                        log_usage("summarize", {
                            "model": selected_model,
                            "word_count": word_count,
                            "token_count": token_count,
                            "elapsed": round(elapsed, 2),
                        })

                        st.toast("✅ Summary saved to database!", icon="💾")
                except Exception as db_err:
                    st.toast(f"⚠️ Could not save to DB: {db_err}", icon="⚠️")
                
            except RuntimeError as e:
                st.error(f"❌ {e}")
                st.info("Make sure Ollama is running: open a terminal and run `ollama serve`")


# ── Display Previous Results ────────────────────────────────────────────
if "last_summary" in st.session_state and not summarize_clicked:
    st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)
    st.markdown('<div class="result-header">📊 Last Summary</div>', unsafe_allow_html=True)
    st.markdown(st.session_state["last_summary"])


# ── Export Section ──────────────────────────────────────────────────────
if "last_summary" in st.session_state:
    elapsed = st.session_state.get("last_elapsed", 0)
    source = st.session_state.get("last_source", "Meeting Transcript")
    
    st.markdown("")
    st.markdown(
        f"""
        <div class="metric-bar">
            <div class="metric-item">⏱️ Processing: <span class="metric-value">{elapsed:.1f}s</span></div>
            <div class="metric-item">📄 Source: <span class="metric-value">{source}</span></div>
            <div class="metric-item">🤖 Engine: <span class="metric-value">Ollama (Local)</span></div>
            <div class="metric-item">💰 Cost: <span class="metric-value" style="color:#10B981;">₹0</span></div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    
    st.markdown("")
    
    # Download buttons
    col_dl1, col_dl2 = st.columns(2)
    
    with col_dl1:
        md_content = to_markdown(st.session_state["last_summary"], source)
        st.download_button(
            "⬇️  Download as Markdown",
            data=md_content,
            file_name="meeting_summary.md",
            mime="text/markdown",
            use_container_width=True,
        )
    
    with col_dl2:
        txt_content = to_plain_text(st.session_state["last_summary"], source)
        st.download_button(
            "⬇️  Download as Text",
            data=txt_content,
            file_name="meeting_summary.txt",
            mime="text/plain",
            use_container_width=True,
        )

    # ── Log export usage on download (Streamlit reruns on download click) ──
    # We use session state to track if an export was just done
    # (download_button triggers a rerun but we can't detect which one;
    #  logging is best-effort here)

    # ── Feedback Widget ─────────────────────────────────────────────────
    st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)
    st.markdown('<div class="section-header">⭐ Rate This Summary</div>', unsafe_allow_html=True)
    st.markdown("")

    summary_id = st.session_state.get("last_summary_id")
    mongo_ok, _ = check_mongo_connection()

    if summary_id and mongo_ok:
        # Check if already rated this summary
        feedback_key = f"feedback_submitted_{summary_id}"

        if st.session_state.get(feedback_key):
            st.markdown(
                """
                <div class="glass-card" style="text-align:center; padding: 1.5rem;">
                    <p style="color: #10B981; font-size: 1.1rem; font-weight: 700; margin: 0;">
                        ✅ Thank you for your feedback!
                    </p>
                </div>
                """,
                unsafe_allow_html=True,
            )
        else:
            col_r, col_c = st.columns([1, 2])
            with col_r:
                rating = st.slider(
                    "Rating",
                    min_value=1,
                    max_value=5,
                    value=4,
                    help="1 = Poor, 5 = Excellent",
                    format="%d ⭐",
                )
            with col_c:
                comment = st.text_input(
                    "Comment (optional)",
                    placeholder="Any feedback on the summary quality?",
                )

            if st.button("📨 Submit Feedback", use_container_width=True):
                try:
                    save_feedback(summary_id, rating, comment)
                    log_usage("feedback", {"summary_id": summary_id, "rating": rating})
                    st.session_state[feedback_key] = True
                    st.toast("⭐ Feedback saved!", icon="✅")
                    st.rerun()
                except Exception as fb_err:
                    st.error(f"Could not save feedback: {fb_err}")
    elif not mongo_ok:
        st.caption("💡 Start MongoDB to enable feedback & history features.")


# ── Footer ──────────────────────────────────────────────────────────────
st.markdown("")
st.markdown(
    '<div class="app-footer">'
    "MeetingMind · Deliverable A — Streamlit App · DBM 03"
    "</div>",
    unsafe_allow_html=True,
)
