# MeetingMind — Presentation Speaker Notes
### DBM 03 · Big Data for Digital Transformation

> This document contains detailed speaker notes for each of the 7 slides in the MeetingMind technical presentation. Use these notes to guide your delivery — they explain what's on screen, what to emphasize, and suggested talking points.

---

## Slide 1 — Title: MeetingMind

**What's on screen:** Project name, one-liner description, four feature cards (Private, ₹0/month, Real-Time, Structured), and the tech stack.

### Speaker Notes

> *"Good [morning/afternoon]. Today we're presenting MeetingMind — a data product we built for this course that solves a very real problem: turning messy, unstructured meeting transcripts into clean, structured summaries."*

**Key points to cover:**

- **What it does:** You paste (or upload) a meeting transcript, and MeetingMind extracts decisions, action items, key discussion points, and an executive summary — all formatted and downloadable.
- **Why it matters:** Meetings generate enormous amounts of unstructured text. Most of it gets lost. MeetingMind turns that into actionable data.
- **Four pillars** (point to each card):
  - **100% Private** — Everything runs locally on your machine. No data leaves the device. No cloud API calls. This is a strong privacy story.
  - **₹0/month** — Because we use Ollama (a local LLM runtime), there's zero marginal cost per summarization. No API keys, no billing.
  - **Real-Time** — The summary streams in token by token as the model generates it, so you see results immediately.
  - **Structured Output** — Not just a paragraph summary. We extract specific categories: decisions, action items with owners and deadlines, open questions.
- **Tech stack:** Python 3.10+, Streamlit for the UI, Ollama as the LLM runtime, and Meta's Llama 3.2 (3B parameter model).
- **Team:** 7 members collaborated on this project.

**Transition:** *"Let me show you the problem we're solving and how our solution works step by step."*

---

## Slide 2 — From Chaos to Clarity

**What's on screen:** Problem card (left), Solution card with output categories (left bottom), and the 4-step workflow (right).

### Speaker Notes

> *"Here's the core problem. Meeting transcripts — whether from Zoom, Teams, or manual notes — are walls of unstructured text."*

**The Problem (point to red card):**
- Decisions get buried in conversation flow
- Action items mentioned verbally are never tracked
- Follow-ups are missed because nobody reads a 2,000-word transcript
- **Critical insight:** This is NOT something a rule-based algorithm can solve. The input is genuinely unpredictable — different speakers, topics, formats, languages. You *need* an LLM.

**Our Solution (point to green card):**
- Walk through the 5 output categories:
  1. **Executive Summary** — 3-5 sentence overview a manager can read in 30 seconds
  2. **Decisions Made** — Numbered list with context ("The team decided to delay launch by 2 weeks because...")
  3. **Action Items** — Structured as a table with Owner, Deadline, and Priority columns
  4. **Key Discussion Points** — Important topics discussed, even if no decision was reached
  5. **Open Questions** — Items that need follow-up in the next meeting

**4-Step Workflow (point to right column):**
1. **Input** — User pastes text or uploads a `.txt` file. Simple.
2. **Validate [Baked-in]** — Python heuristics check word count, estimate token count (~1.33 tokens/word), verify the input isn't empty or too short. No LLM needed here.
3. **Summarize [API-in-the-Loop]** — This is the only step that calls the LLM. The transcript is sent to Ollama with a carefully crafted system prompt. The response streams back in real time.
4. **Export [Baked-in]** — The summary is formatted as Markdown or plain text using string templates. Again, no LLM — just formatting.

> *"Notice that only Step 3 uses the LLM. Everything else is deterministic Python code. This is the API-in-the-loop concept — we'll dive deeper into that in Slide 4."*

**Transition:** *"Let's look at the technical architecture."*

---

## Slide 3 — System Design & Stack

**What's on screen:** Project file structure (left), architecture layers (right top), key design decisions (left bottom), tech stack (right bottom).

### Speaker Notes

> *"Here's how the codebase is organized. It's a multi-page Streamlit application with a clear separation of concerns."*

**Project Structure (point to code block):**
- `app.py` — The landing/home page. Hero section, feature overview, getting started guide.
- `pages/` — Streamlit's multi-page convention. Three pages map to three deliverables:
  - `1_📝_Summarizer.py` → **Deliverable A** (the core product)
  - `2_💰_Operating_Budget.py` → **Deliverable B** (cost analysis)
  - `3_🏷️_Pricing.py` → **Deliverable C** (customer pricing)
- `utils/` — Shared modules:
  - `ollama_client.py` — Wraps the Ollama Python SDK. Contains the system prompt, connection check, model listing, and streaming summarization function.
  - `text_processing.py` — Baked-in heuristics: word count, token estimation, input validation, text chunking.
  - `export.py` — Template-based formatters for Markdown and plain text export.
  - `styles.py` — Centralized CSS module (eliminates ~800 lines of duplication across pages).
  - `sidebar.py` — Shared sidebar component with connection status badge.

**Architecture Layers (point to right column):**
- **Layer 1: Streamlit Frontend** — Multi-page app with dark theme, glassmorphism cards, Lottie animations. All CSS is centralized in `styles.py`.
- **Layer 2: Prompt Engineering Layer [BAKED IN]** — The system prompt is hand-crafted and frozen at build time. Input validation and export templates are also static — no LLM involvement.
- **Layer 3: Ollama Python Client [API-IN-THE-LOOP]** — This is the only layer that makes a runtime LLM call. It sends the transcript + system prompt to Llama 3.2 and streams the response back.

**Key Design Decisions:**
- We chose **shared CSS/sidebar modules** to avoid duplicating ~200 lines of CSS across 4 files (DRY principle).
- We use **streaming** (`ollama.chat(stream=True)`) so users see the summary appearing in real time rather than waiting.
- **Low temperature (0.3)** — We want factual extraction, not creative writing. Low temperature keeps the model grounded.
- **Cached connection check** — `check_connection()` is cached for 30 seconds so it doesn't hit the Ollama server on every Streamlit re-render.

**Tech Stack:**
- All four components are **free and open-source**. Total infrastructure cost: ₹0.

**Transition:** *"Now let's talk about the most important course concept — when should intelligence be baked in versus called at runtime?"*

---

## Slide 4 — API-in-the-Loop vs. Baked-In

**What's on screen:** Feature classification table (6 rows) and a takeaway card at the bottom.

### Speaker Notes

> *"This is the core course concept. The question is: for every intelligent feature in your product, should the intelligence be baked in at build time, or called at runtime via an API?"*

**The Table (walk through each row):**

1. **Meeting Summarization → API-in-the-Loop**
   - *"This is the ONE feature that genuinely needs a runtime LLM call. Why? Because every meeting transcript is different. You can't pre-compute or template a summary of text you've never seen before. The input is genuinely unstructured and unpredictable. This is the textbook case for API-in-the-loop."*

2. **System Prompt → Baked In**
   - *"The prompt that tells the LLM how to format the summary — sections, bullet points, action item tables — is identical for every request. We wrote it once and froze it. There's no reason to generate or modify it at runtime."*

3. **Input Validation → Baked In**
   - *"Counting words, estimating tokens (~1.33 tokens per word), checking if the input is too short — these are simple Python heuristics. Using an LLM for this would be wasteful."*

4. **Export Formatting → Baked In**
   - *"Converting the summary to downloadable Markdown or plain text is just string manipulation. Templates, regex stripping — deterministic. This saves one potential API call per export."*

5. **Cost Calculations → Baked In**
   - *"The operating budget and pricing pages are pure math — unit cost × volume = total. No LLM needed. It would be absurd to call GPT-4 to multiply numbers."*

6. **UI Layout & Styling → Baked In**
   - *"The glassmorphism UI, sidebar, animations — all CSS rendered client-side. Static by definition."*

**Key Takeaway (point to bottom card):**
> *"By choosing Ollama — a local LLM runtime — even our one API-in-the-loop call costs ₹0. If we had used GPT-4o instead, each 2,000-word transcript would cost approximately ₹3.50. At 200 meetings per month, that's ₹700/month just for inference."*

> *"We moved 5 of 6 intelligent features completely out of the loop. Only the core summarization remains as a runtime call. This is deliberate architecture — minimize the blast radius of the most expensive, least predictable component."*

**Transition:** *"So what does this mean for our operating costs? Let's look at the budget."*

---

## Slide 5 — Operating Budget (Deliverable B)

**What's on screen:** Two cost tables side by side — Ollama (local) vs GPT-4o (cloud), plus savings stats at bottom right.

### Speaker Notes

> *"This is Deliverable B — the back-end operating budget. We model costs at a reference volume of 200 meetings per month, 2,000 words per transcript, and 50 active users."*

**Ollama / Local Deployment (point to left table):**
- *"Walk through each line item:"*
  - **Storage** — Transcripts and summaries stored on local disk. Cost: ₹0.
  - **Compute** — Model runs on the user's own CPU/GPU. No cloud compute. Cost: ₹0.
  - **Model Inference** — Llama 3.2 runs through Ollama locally. No per-token billing. Cost: ₹0.
  - **Dashboards** — Streamlit runs locally or on Streamlit Community Cloud (free tier). Cost: ₹0.
  - **Data Ingress/Egress** — All data stays on the local machine. No network transfer. Cost: ₹0.
  - **TOTAL: ₹0/month** — *"Every single cost line is zero. This is the power of running your own LLM."*

**Cloud Alternative / GPT-4o (point to right table):**
- *"Now let's see what it would cost if we used OpenAI's GPT-4o instead:"*
  - **Input tokens:** 200 meetings × 2,660 tokens ≈ 532K tokens → ₹112/month
  - **Output tokens:** 200 meetings × 800 tokens ≈ 160K tokens → ₹1,344/month (output tokens cost 3× more with GPT-4o)
  - **Hosting + Storage:** Streamlit Cloud + Supabase free tiers → ₹0
  - **TOTAL: ₹1,456/month**

**Savings (point to bottom stats):**
> *"That's a ₹1,456/month savings by choosing Ollama over GPT-4o. At scale — say 1,000 meetings/month — the savings become ₹7,280/month or nearly ₹87,000/year."*

> *"The tradeoff is that Llama 3.2 (3B) is a smaller model than GPT-4o. For our use case — structured extraction from meeting transcripts — the quality is sufficient. We're not writing poetry; we're pulling out decisions and action items."*

**Key talking point if asked about scalability:**
- The budget page in the app has **interactive sliders** — you can adjust meetings/month, words/transcript, and user count in real time and see the cost table update dynamically.

**Transition:** *"Given that our operating cost is essentially zero, how do we price this for customers?"*

---

## Slide 6 — Customer Pricing (Deliverable C)

**What's on screen:** Three pricing cards (Free, Pro, Enterprise) and a margin analysis bar at the bottom.

### Speaker Notes

> *"This is Deliverable C — customer-facing pricing derived from our operating budget."*

**Pricing Strategy:**
> *"We chose a tiered model — Free, Pro, Enterprise — for three reasons:"*
1. **Low barrier** — The free tier lets anyone try MeetingMind with zero risk. 20 summaries/month, paste-only input.
2. **Natural upgrade** — As individuals become teams, they naturally need file upload, unlimited summaries, and custom prompts → Pro at ₹499/user/month.
3. **Predictable billing** — Per-seat monthly pricing is easier for enterprises to budget than usage-based. Enterprises get SSO, API access, custom fine-tuning, and dedicated support at ₹1,499/user/month.

**Walk through each tier:**

- **Free (₹0):** 20 summaries/month, paste input only, basic summary, TXT download. Good for individual evaluation.
- **Pro (₹499/user/month):** Unlimited summaries, file upload, full structured output, MD + TXT download, priority processing, custom prompt templates. This is the sweet spot for professionals.
- **Enterprise (₹1,499/user/month):** Everything in Pro plus team workspace, admin dashboard, SSO integration, API access, custom model fine-tuning, dedicated support, and on-premise deployment option.

**Why not usage-based pricing?**
> *"Meeting volume is unpredictable — some weeks you have 10 meetings, some weeks 2. Users strongly prefer predictable monthly bills over per-summary charges."*

**Margin Analysis (point to bottom bar):**
> *"With just 30 Pro users and 10 Enterprise users:"*
- Monthly Revenue = (30 × ₹499) + (10 × ₹1,499) = **₹29,960**
- Monthly Cost (hosting, support overhead) ≈ **₹1,000**
- Gross Margin = **₹28,960** → **96.7%**
- *"The near-zero marginal cost of Ollama is what enables this margin. Every new user costs us essentially nothing in compute."*

**Transition:** *"Let me wrap up with the key takeaways."*

---

## Slide 7 — Key Takeaways

**What's on screen:** Three takeaway cards (left), deliverables recap + engineering highlights + demo card (right).

### Speaker Notes

> *"Let me summarize the three big ideas from this project."*

**1. Intelligence Placement (point to brain card):**
> *"Only 1 of 6 intelligent features runs at runtime — the meeting summarization. Everything else — the system prompt, validation, export, cost calculations, UI — is baked in. This is deliberate. Baked-in intelligence is cheaper, faster, and more reliable. You should only use API-in-the-loop when the input is genuinely unpredictable."*

**2. Cost Advantage (point to money card):**
> *"By running Ollama locally, our operating cost is ₹0. The cloud alternative would cost ₹1,456/month at the same volume. This cost structure enables a 96.7% gross margin even at an accessible ₹499/user price point. The economics only work because we chose local inference."*

**3. Privacy by Design (point to lock card):**
> *"All processing happens locally. No data ever leaves the machine — no cloud APIs, no API keys, no third-party data processors. This isn't a feature we bolted on; it's a consequence of the architecture. If you're summarizing confidential board meetings or HR conversations, this matters enormously."*

**Deliverables Recap (point to right column):**
- **A** — The Streamlit app itself (multi-page, streaming, dark theme)
- **B** — Operating budget with interactive sliders
- **C** — Customer pricing with tiered cards and margin analysis

**Engineering Highlights:**
- Shared CSS & sidebar modules (eliminated ~800 lines of duplication)
- Streaming LLM output for real-time user experience
- Cached connection checks to avoid redundant network calls
- Token estimation heuristic for input validation
- Regex-based Markdown → Plain Text conversion for clean exports

**Demo (point to bottom card):**
> *"And with that, let me show you the app live. It's running right now at localhost:8501."*

→ Switch to browser and demo the Summarizer page with the sample transcript.

---

## Demo Script (Bonus)

If you're doing a live demo after the slides, here's a suggested flow:

1. **Home page** — Show the landing page briefly. Point out the Ollama connection status in the sidebar.
2. **Summarizer page** — Click "Load Sample Transcript" to load the built-in example. Point out the word count and token estimate in the metric bar. Click "Summarize Meeting" and let the audience watch the streaming output.
3. **Download** — Show the Markdown and TXT download buttons. Open the downloaded file briefly.
4. **Budget page** — Drag the sliders to show how costs change dynamically. Point out that the Ollama column stays at ₹0 regardless of volume.
5. **Pricing page** — Show the three pricing cards. Scroll down to the margin analysis and cost breakdown tables.

**Timing:** Aim for 1.5-2 minutes per slide (10-14 minutes total), plus 3-5 minutes for the live demo.

---

*Document generated for the MeetingMind project — DBM 03, Big Data for Digital Transformation.*
