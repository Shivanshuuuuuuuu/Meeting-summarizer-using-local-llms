"""
📜 History & Analytics Page
============================
Browse past meeting summaries, view feedback, and see usage analytics.
All data is stored in and retrieved from MongoDB.
"""

import os
import sys
import streamlit as st
import pandas as pd
from datetime import datetime

st.set_page_config(
    page_title="History — MeetingMind",
    page_icon="📜",
    layout="wide",
)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ── Shared Styles & Sidebar ─────────────────────────────────────────────
from utils.styles import inject_global_css
from utils.sidebar import render_sidebar
from utils.db_client import (
    check_mongo_connection,
    get_all_summaries,
    get_summary_by_id,
    delete_summary,
    get_feedback_for_summary,
    get_usage_stats,
)

inject_global_css()
render_sidebar(
    show_connection=False,
    badge_label="History",
    badge_detail="Browse past summaries<br>and usage analytics",
)

# History-page-specific CSS
st.markdown("""
<style>
    .history-card {
        background: rgba(26, 29, 41, 0.6);
        border: 1px solid rgba(108, 99, 255, 0.1);
        border-radius: 16px;
        padding: 1.5rem;
        margin-bottom: 0.8rem;
        transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
    }

    .history-card::before {
        content: '';
        position: absolute;
        top: 0; left: 0;
        width: 3px; height: 100%;
        background: linear-gradient(180deg, #6C63FF, #00D4AA);
        border-radius: 3px 0 0 3px;
    }

    .history-card:hover {
        border-color: rgba(108, 99, 255, 0.25);
        box-shadow: 0 6px 25px rgba(108, 99, 255, 0.1);
        transform: translateY(-2px);
    }

    .history-title {
        font-size: 1rem;
        font-weight: 700;
        color: #EAEAEA;
        margin-bottom: 0.3rem;
    }

    .history-meta {
        font-size: 0.78rem;
        color: #6B7280;
        display: flex;
        gap: 1.2rem;
        flex-wrap: wrap;
        margin-top: 0.4rem;
    }

    .history-meta span {
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
    }

    .analytics-card {
        background: rgba(26, 29, 41, 0.6);
        border: 1px solid rgba(108, 99, 255, 0.1);
        border-radius: 16px;
        padding: 1.8rem 1.5rem;
        text-align: center;
        transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .analytics-card:hover {
        border-color: rgba(108, 99, 255, 0.25);
        box-shadow: 0 8px 30px rgba(108, 99, 255, 0.1);
        transform: translateY(-4px);
    }

    .analytics-number {
        font-size: 2.2rem;
        font-weight: 900;
        background: linear-gradient(135deg, #6C63FF, #00D4AA);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        letter-spacing: -0.03em;
    }

    .analytics-label {
        font-size: 0.78rem;
        color: #6B7280;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        margin-top: 0.3rem;
    }

    .feedback-stars {
        color: #F59E0B;
        font-size: 1.1rem;
        letter-spacing: 2px;
    }

    .empty-state {
        text-align: center;
        padding: 4rem 2rem;
        color: #6B7280;
    }

    .empty-state-icon {
        font-size: 4rem;
        margin-bottom: 1rem;
    }

    .empty-state-text {
        font-size: 1.1rem;
        color: #9CA3AF;
        margin-bottom: 0.5rem;
    }

    .empty-state-hint {
        font-size: 0.85rem;
        color: #6B7280;
    }
</style>
""", unsafe_allow_html=True)


# ── Page Header ─────────────────────────────────────────────────────────
st.markdown('<div class="page-header">📜 History & Analytics</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="page-subtitle">'
    "Browse past meeting summaries, view feedback, and track your usage analytics. "
    "All data is stored locally in MongoDB."
    "</div>",
    unsafe_allow_html=True,
)
st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)


# ── Connection Check ───────────────────────────────────────────────────
mongo_ok, mongo_msg = check_mongo_connection()

if not mongo_ok:
    st.markdown(
        """
        <div class="empty-state">
            <div class="empty-state-icon">🔌</div>
            <div class="empty-state-text">MongoDB is not connected</div>
            <div class="empty-state-hint">
                Start MongoDB to view your history and analytics.<br>
                Run <code>mongod</code> in a terminal to start the server.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.stop()


# ── Tab Layout ──────────────────────────────────────────────────────────
tab_history, tab_analytics = st.tabs(["📜  Summary History", "📊  Usage Analytics"])


# ═══════════════════════════════════════════════════════════════════════
# TAB 1: Summary History
# ═══════════════════════════════════════════════════════════════════════
with tab_history:
    summaries = get_all_summaries(limit=100)

    if not summaries:
        st.markdown(
            """
            <div class="empty-state">
                <div class="empty-state-icon">📝</div>
                <div class="empty-state-text">No summaries yet</div>
                <div class="empty-state-hint">
                    Head over to the <strong>📝 Summarizer</strong> page to create your first summary.<br>
                    It will automatically appear here!
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
    else:
        st.markdown(f"**{len(summaries)}** summaries found")
        st.markdown("")

        for i, doc in enumerate(summaries):
            created = doc.get("created_at")
            if created:
                time_str = created.strftime("%b %d, %Y at %I:%M %p")
            else:
                time_str = "Unknown"

            source = doc.get("source", "Unknown")
            model = doc.get("model", "Unknown")
            words = doc.get("word_count", 0)
            tokens = doc.get("token_count", 0)
            elapsed = doc.get("elapsed_seconds", 0)
            doc_id = doc.get("id", "")

            # Get feedback for this summary
            feedbacks = get_feedback_for_summary(doc_id)
            avg_rating = 0
            if feedbacks:
                avg_rating = sum(f.get("rating", 0) for f in feedbacks) / len(feedbacks)

            stars_html = ""
            if avg_rating > 0:
                full_stars = int(avg_rating)
                stars_html = f'<span class="feedback-stars">{"★" * full_stars}{"☆" * (5 - full_stars)}</span>'

            # Summary card
            st.markdown(
                f"""
                <div class="history-card">
                    <div class="history-title">📄 {source}</div>
                    <div class="history-meta">
                        <span>🕐 {time_str}</span>
                        <span>🤖 {model}</span>
                        <span>📝 {words:,} words</span>
                        <span>⏱️ {elapsed:.1f}s</span>
                        {f'<span>{stars_html}</span>' if stars_html else ''}
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

            # Expandable details
            with st.expander(f"View Details — {source} ({time_str})", expanded=False):
                detail_tab1, detail_tab2, detail_tab3 = st.tabs(["📊 Summary", "📝 Transcript", "⭐ Feedback"])

                with detail_tab1:
                    st.markdown(doc.get("summary", "*No summary available*"))

                with detail_tab2:
                    transcript = doc.get("transcript", "")
                    if transcript:
                        st.text_area(
                            "Original Transcript",
                            value=transcript,
                            height=200,
                            disabled=True,
                            key=f"transcript_{doc_id}",
                        )
                    else:
                        st.caption("No transcript stored.")

                with detail_tab3:
                    if feedbacks:
                        for fb in feedbacks:
                            rating = fb.get("rating", 0)
                            comment = fb.get("comment", "")
                            fb_time = fb.get("created_at")
                            fb_time_str = fb_time.strftime("%b %d, %Y") if fb_time else ""

                            stars = "⭐" * rating + "☆" * (5 - rating)
                            st.markdown(
                                f"""
                                <div class="glass-card" style="padding: 1rem 1.2rem; margin-bottom: 0.5rem;">
                                    <span style="font-size: 1.1rem;">{stars}</span>
                                    <span style="color: #6B7280; font-size: 0.8rem; margin-left: 0.5rem;">{fb_time_str}</span>
                                    {"<br><span style='color: #D1D5DB; font-size: 0.9rem;'>" + comment + "</span>" if comment else ""}
                                </div>
                                """,
                                unsafe_allow_html=True,
                            )
                    else:
                        st.caption("No feedback yet for this summary.")

                # Delete button
                st.markdown("")
                if st.button(f"🗑️ Delete This Summary", key=f"delete_{doc_id}", type="secondary"):
                    delete_summary(doc_id)
                    st.toast("🗑️ Summary deleted!", icon="✅")
                    st.rerun()


# ═══════════════════════════════════════════════════════════════════════
# TAB 2: Usage Analytics
# ═══════════════════════════════════════════════════════════════════════
with tab_analytics:
    stats = get_usage_stats()

    # ── Stat Cards Row ──────────────────────────────────────────────────
    col1, col2, col3, col4 = st.columns(4)

    with col1:
        st.markdown(
            f"""
            <div class="analytics-card animate-in animate-in-delay-1">
                <div class="analytics-number">{stats['total_summaries']}</div>
                <div class="analytics-label">Total Summaries</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col2:
        total_tokens = stats["total_tokens"]
        tokens_display = f"{total_tokens / 1000:.1f}K" if total_tokens >= 1000 else str(total_tokens)
        st.markdown(
            f"""
            <div class="analytics-card animate-in animate-in-delay-2">
                <div class="analytics-number">{tokens_display}</div>
                <div class="analytics-label">Tokens Processed</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col3:
        st.markdown(
            f"""
            <div class="analytics-card animate-in animate-in-delay-3">
                <div class="analytics-number">{stats['avg_processing_time']}s</div>
                <div class="analytics-label">Avg Processing Time</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col4:
        avg_rating = stats["avg_rating"]
        rating_display = f"{avg_rating} ⭐" if avg_rating > 0 else "—"
        st.markdown(
            f"""
            <div class="analytics-card animate-in animate-in-delay-4">
                <div class="analytics-number" style="font-size: 1.8rem;">{rating_display}</div>
                <div class="analytics-label">Avg Rating</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)

    # ── Secondary Stats Row ─────────────────────────────────────────────
    col_a, col_b = st.columns(2)

    with col_a:
        st.markdown(
            f"""
            <div class="analytics-card">
                <div class="analytics-number" style="font-size: 1.8rem;">{stats['total_exports']}</div>
                <div class="analytics-label">Total Exports</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col_b:
        st.markdown(
            f"""
            <div class="analytics-card">
                <div class="analytics-number" style="font-size: 1.8rem;">{stats['total_feedback']}</div>
                <div class="analytics-label">Feedback Entries</div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)

    # ── Summaries Per Day Chart ─────────────────────────────────────────
    st.markdown('<div class="section-header">📈 Summaries Per Day</div>', unsafe_allow_html=True)
    st.markdown("")

    daily_data = stats.get("summaries_by_day", {})

    if daily_data:
        df_daily = pd.DataFrame(
            list(daily_data.items()),
            columns=["Date", "Summaries"],
        )
        df_daily["Date"] = pd.to_datetime(df_daily["Date"])
        df_daily = df_daily.set_index("Date").sort_index()
        st.bar_chart(df_daily, color="#6C63FF")
    else:
        st.caption("No data yet — summarize a few meetings to see the chart.")

    st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)

    # ── Model Usage Breakdown ───────────────────────────────────────────
    st.markdown('<div class="section-header">🤖 Model Usage</div>', unsafe_allow_html=True)
    st.markdown("")

    model_data = stats.get("model_usage", {})

    if model_data:
        for model_name, count in model_data.items():
            pct = (count / stats["total_summaries"] * 100) if stats["total_summaries"] > 0 else 0
            st.markdown(
                f"""
                <div class="glass-card" style="padding: 1rem 1.5rem; margin-bottom: 0.5rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #EAEAEA; font-weight: 600;">🤖 {model_name}</span>
                        <span style="color: #8B83FF; font-weight: 700;">{count} runs ({pct:.0f}%)</span>
                    </div>
                    <div style="margin-top: 0.5rem; background: rgba(108,99,255,0.1); border-radius: 100px; height: 6px; overflow: hidden;">
                        <div style="width: {pct}%; height: 100%; background: linear-gradient(90deg, #6C63FF, #00D4AA); border-radius: 100px;"></div>
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )
    else:
        st.caption("No model usage data yet.")


# ── Footer ──────────────────────────────────────────────────────────────
st.markdown("")
st.markdown(
    '<div class="app-footer">'
    "MeetingMind · History & Analytics · Powered by MongoDB · DBM 03"
    "</div>",
    unsafe_allow_html=True,
)
