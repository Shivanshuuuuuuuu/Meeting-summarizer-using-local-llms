@echo off
title MeetingMind — Starting Up...
color 0A

echo.
echo  ============================================
echo   🧠  MeetingMind — Meeting Summarizer
echo  ============================================
echo.

:: ── Start MongoDB (if not already running) ──
echo  [1/3] Checking MongoDB...
tasklist /FI "IMAGENAME eq mongod.exe" 2>NUL | find /I "mongod.exe" >NUL
if %ERRORLEVEL% == 0 (
    echo         MongoDB is already running. ✓
) else (
    echo         Starting MongoDB...
    start "" /MIN mongod
    timeout /t 3 /nobreak >NUL
    echo         MongoDB started. ✓
)

echo.

:: ── Start Ollama (if not already running) ──
echo  [2/3] Checking Ollama...
tasklist /FI "IMAGENAME eq ollama.exe" 2>NUL | find /I "ollama.exe" >NUL
if %ERRORLEVEL% == 0 (
    echo         Ollama is already running. ✓
) else (
    echo         Starting Ollama...
    start "" /MIN ollama serve
    timeout /t 3 /nobreak >NUL
    echo         Ollama started. ✓
)

echo.

:: ── Launch Streamlit App ──
echo  [3/3] Launching MeetingMind...
echo.
echo  ============================================
echo   App will open at http://localhost:8501
echo   Press Ctrl+C in this window to stop.
echo  ============================================
echo.

streamlit run "%~dp0app.py"

pause
