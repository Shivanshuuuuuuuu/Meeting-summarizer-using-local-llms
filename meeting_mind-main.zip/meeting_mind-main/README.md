# 🧠 MeetingMind — Meeting Notes & Transcript Summarizer

> Turn walls of meeting text into crystal-clear decisions and action items.
> Powered by Ollama (free local LLM) — your data never leaves your machine.

**Course**: DBM 03 — Big Data for Digital Transformation  
**Project**: Data Product — Meeting Notes Summarizer  
**Team Size**: 7 members

---

## 🎯 What It Does

MeetingMind takes raw, unstructured meeting transcripts and extracts:

- 📋 **Executive Summary** — 3-5 sentence overview
- ✅ **Decisions Made** — numbered list with context
- 🎯 **Action Items** — table with Owner, Deadline, Priority
- 💬 **Key Discussion Points** — bullet list of important topics
- ⚠️ **Open Questions** — unresolved items for follow-up

All summaries, feedback, and usage analytics are persisted in **MongoDB**.

## 🏗️ Architecture

```
Streamlit Frontend (UI)
    ├── 📝 Summarizer Page     ← Core product (Deliverable A)
    ├── 💰 Operating Budget    ← Cost analysis (Deliverable B)
    ├── 🏷️ Pricing Page        ← Customer pricing (Deliverable C)
    └── 📜 History & Analytics ← Browse past summaries + usage stats
            │
            ▼
  Prompt Engineering Layer
  (System prompt — baked in)
            │
            ▼
    Ollama Python Client          MongoDB (Local)
    (Llama 3.2 — API-in-the-loop) (Summaries, Feedback, Analytics)
```

## 🔄 API-in-the-Loop vs. Baked-In

| Feature | Type | Why |
|---|---|---|
| Meeting Summarization | 🔴 API-in-the-loop | Each transcript is unique unstructured text |
| System Prompt | 🟢 Baked-in | Same template for every request |
| Input Validation | 🟢 Baked-in | Deterministic Python heuristics |
| Export Formatting | 🟢 Baked-in | Template-based string formatting |
| Cost Calculations | 🟢 Baked-in | Deterministic math |
| Data Persistence | 🟢 Baked-in | MongoDB CRUD — no LLM needed |

**Key Teaching Point**: Summarization is the rare counter-example where a runtime LLM call is justified — the input is genuinely unstructured and unpredictable.

## 🚀 Setup & Run

### Prerequisites
- Python 3.10+
- [Ollama](https://ollama.com/) installed and running
- Llama 3.2 model pulled: `ollama pull llama3.2`
- [MongoDB](https://www.mongodb.com/try/download/community) installed and running

### Installation

```bash
# Clone the repository
git clone <your-github-url>
cd bigdata-project

# Install dependencies
pip install -r requirements.txt

# Make sure Ollama is running (it usually auto-starts)
ollama list  # Should show llama3.2

# Make sure MongoDB is running
mongod       # Start MongoDB server (or it may auto-start as a service)

# Run the app
streamlit run app.py
```

The app will open at `http://localhost:8501`.

## 📁 Project Structure

```
bigdata project/
├── app.py                          # Main Streamlit entry point
├── requirements.txt                # Python dependencies
├── README.md                       # This file
├── .gitignore
├── data/
│   └── sample_transcript.txt       # Demo meeting transcript
├── pages/
│   ├── 1_📝_Summarizer.py          # Core summarizer (Deliverable A)
│   ├── 2_💰_Operating_Budget.py    # Cost sheet (Deliverable B)
│   ├── 3_🏷️_Pricing.py            # Pricing model (Deliverable C)
│   └── 4_📜_History.py             # History browser & analytics
└── utils/
    ├── __init__.py
    ├── ollama_client.py            # Ollama API wrapper
    ├── db_client.py                # MongoDB client wrapper
    ├── text_processing.py          # Text utilities
    ├── export.py                   # Export formatting
    ├── sidebar.py                  # Shared sidebar component
    └── styles.py                   # Shared CSS styles
```

## 💰 Tech Stack & Cost

| Layer | Technology | Monthly Cost |
|---|---|---|
| Frontend | Streamlit | ₹0 (free) |
| LLM Backend | Ollama (local) | ₹0 (free) |
| Model | Llama 3.2 (3B) | ₹0 (free) |
| Database | MongoDB (local) | ₹0 (free) |
| Language | Python 3.10+ | ₹0 (free) |
| **Total** | | **₹0 / month** |

## 🗄️ MongoDB Collections

| Collection | Purpose |
|---|---|
| `summaries` | Stores transcript, summary, model, timing, and metadata for each meeting |
| `feedback` | Star ratings (1-5) and comments linked to summaries |
| `analytics` | Event log for usage tracking (summarize, export, page_view) |

## 📄 License

This project was built for academic purposes as part of the DBM 03 course.
