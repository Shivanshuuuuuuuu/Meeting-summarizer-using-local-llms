"""
Ollama Client Wrapper
Handles all communication with the local Ollama LLM server.
This is the API-in-the-loop component — the only runtime LLM call in the product.
"""

import ollama
import streamlit as st


# ---------------------------------------------------------------------------
# System prompt — this is the "baked-in" part. It never changes per request.
# The actual summarization is the "API-in-the-loop" part — it MUST run at
# runtime because each transcript is unique unstructured text.
# ---------------------------------------------------------------------------
SYSTEM_PROMPT = """You are an expert meeting analyst. Your job is to transform raw meeting transcripts or notes into a clean, structured summary.

Analyze the provided text and extract the following sections. Use EXACTLY these headers and formatting:

## 📋 Executive Summary
Write 3-5 sentences summarizing the overall meeting — what was discussed, the tone, and key outcomes.

## ✅ Decisions Made
List every decision that was made during the meeting as a numbered list. Include context for each decision.

## 🎯 Action Items
Create a markdown table with these columns: | # | Action Item | Owner | Deadline | Priority |
- For Priority use: P0 (critical), P1 (high), P2 (medium), P3 (low)
- If no deadline is explicitly mentioned, write "TBD"
- If no owner is clear, write "Unassigned"

## 💬 Key Discussion Points
Bullet-point list of the important topics that were discussed, with brief context.

## ⚠️ Open Questions & Parking Lot
List any unresolved questions, deferred items, or topics that need follow-up.

Rules:
- Be thorough — do not miss any decisions or action items
- Use the exact names/roles mentioned in the transcript
- Keep the tone professional and concise
- If the input is not a meeting transcript, politely say so and ask for a valid transcript
"""


@st.cache_data(ttl=30, show_spinner=False)
def check_connection():
    """Check if Ollama server is running and reachable. Cached for 30s."""
    try:
        ollama.list()
        return True, "Connected"
    except Exception as e:
        return False, str(e)


def get_available_models():
    """Return list of model names available in Ollama."""
    try:
        response = ollama.list()
        models = [m.model for m in response.models]
        return models if models else ["llama3.2"]
    except Exception:
        return ["llama3.2"]



def summarize_transcript_stream(transcript: str, model: str = "llama3.2"):
    """
    Streaming version — yields chunks as they arrive for real-time display.
    
    Args:
        transcript: Raw meeting transcript text
        model: Ollama model name to use
        
    Yields:
        Text chunks as they are generated
    """
    try:
        stream = ollama.chat(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Here is the meeting transcript to analyze:\n\n{transcript}"},
            ],
            options={
                "temperature": 0.3,
                "num_predict": 4096,
            },
            stream=True,
        )
        for chunk in stream:
            yield chunk["message"]["content"]
    except Exception as e:
        raise RuntimeError(f"Ollama streaming failed: {e}")
