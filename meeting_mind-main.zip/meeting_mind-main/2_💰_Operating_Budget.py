"""
💰 Operating Budget Page — Deliverable B
==========================================
Monthly cost sheet for running the MeetingMind product at a stated volume.
Every rupee is traced to a driver: unit × volume = line total.
"""

import os
import sys
import streamlit as st
import pandas as pd

st.set_page_config(
    page_title="Operating Budget — MeetingMind",
    page_icon="💰",
    layout="wide",
)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ── Shared Styles & Sidebar ─────────────────────────────────────────────
from utils.styles import inject_global_css
from utils.sidebar import render_sidebar

inject_global_css()
render_sidebar(
    show_connection=False,
    badge_label="Deliverable B",
    badge_detail="Back-end operating budget<br>with unit × volume costing",
)



# ── Page Header ─────────────────────────────────────────────────────────
st.markdown('<div class="page-header">💰 Operating Budget</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="page-subtitle">'
    "Monthly cost sheet for running MeetingMind at stated volume. "
    "Every rupee is traced to a driver — unit × volume = line total."
    "</div>",
    unsafe_allow_html=True,
)
st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)


# ── Volume Assumptions (Interactive) ────────────────────────────────────
st.markdown('<div class="section-header">📊 Volume Assumptions</div>', unsafe_allow_html=True)
st.markdown("Adjust the sliders to model different usage scenarios.")
st.markdown("")

col1, col2, col3 = st.columns(3)

with col1:
    meetings_per_month = st.slider(
        "Meetings / month",
        min_value=10,
        max_value=5000,
        value=200,
        step=10,
        help="Number of meetings summarized per month",
    )

with col2:
    avg_words_per_transcript = st.slider(
        "Avg words / transcript",
        min_value=500,
        max_value=10000,
        value=2000,
        step=100,
        help="Average word count per meeting transcript",
    )

with col3:
    num_users = st.slider(
        "Active users",
        min_value=1,
        max_value=500,
        value=50,
        step=5,
        help="Number of active users on the platform",
    )


# ── Derived Metrics ─────────────────────────────────────────────────────
from utils.text_processing import estimate_tokens

# Use shared heuristic (~1.33 tokens per word) instead of hardcoding
avg_tokens = estimate_tokens("x " * avg_words_per_transcript)  # estimate from word count
total_tokens_month = meetings_per_month * avg_tokens
total_input_tokens = total_tokens_month
total_output_tokens = int(meetings_per_month * 800)
storage_gb = (meetings_per_month * (avg_words_per_transcript * 5 + 4000)) / (1024**3)

st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)


# ── Cost Breakdown — Local (Styled HTML Table) ─────────────────────────
st.markdown('<div class="section-header">📋 Monthly Cost — Ollama (Local Deployment)</div>', unsafe_allow_html=True)
st.markdown("")

st.markdown(
    f"""
    <div class="glass-card">
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Cost Line</th>
                    <th>Unit</th>
                    <th>Unit Cost</th>
                    <th>Volume</th>
                    <th>Line Total (₹/mo)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Storage (transcripts + summaries)</td>
                    <td>GB-month</td>
                    <td>₹0 (local disk)</td>
                    <td>{storage_gb:.3f} GB</td>
                    <td class="cost-zero">₹0</td>
                </tr>
                <tr>
                    <td>Compute (Ollama on local CPU/GPU)</td>
                    <td>vCPU-hour</td>
                    <td>₹0 (local HW)</td>
                    <td>~{meetings_per_month * 0.02:.1f} hrs</td>
                    <td class="cost-zero">₹0</td>
                </tr>
                <tr>
                    <td>Model Inference (Llama 3.2 via Ollama)</td>
                    <td>per call</td>
                    <td>₹0 (local model)</td>
                    <td>{meetings_per_month:,} calls</td>
                    <td class="cost-zero">₹0</td>
                </tr>
                <tr>
                    <td>Dashboards & BI (Streamlit)</td>
                    <td>per month</td>
                    <td>₹0 (Community Cloud)</td>
                    <td>1 instance</td>
                    <td class="cost-zero">₹0</td>
                </tr>
                <tr>
                    <td>Data Ingest & Pipeline (file I/O)</td>
                    <td>per month</td>
                    <td>₹0 (local)</td>
                    <td>1 pipeline</td>
                    <td class="cost-zero">₹0</td>
                </tr>
                <tr>
                    <td>Data Egress / Transfer</td>
                    <td>per month</td>
                    <td>₹0 (local)</td>
                    <td>N/A</td>
                    <td class="cost-zero">₹0</td>
                </tr>
            </tbody>
        </table>
    </div>
    """,
    unsafe_allow_html=True,
)

# Total
st.markdown(
    """
    <div class="glass-card" style="text-align:center; padding: 2rem;">
        <div class="big-number">₹0 / month</div>
        <div class="big-label">Total Operating Cost (Ollama Local)</div>
    </div>
    """,
    unsafe_allow_html=True,
)


# ── Cloud Alternative Comparison ────────────────────────────────────────
st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="section-header">☁️ Cloud Alternative (if we used APIs instead)</div>', unsafe_allow_html=True)
st.markdown("")

usd_to_inr = 84
cost_per_1k_input = (2.50 / 1000) * usd_to_inr
cost_per_1k_output = (10.00 / 1000) * usd_to_inr

cloud_input_cost = (total_input_tokens / 1000) * cost_per_1k_input
cloud_output_cost = (total_output_tokens / 1000) * cost_per_1k_output
cloud_total = cloud_input_cost + cloud_output_cost
hosting_cost = 0 if num_users <= 100 else 1680
cloud_grand_total = cloud_total + hosting_cost

st.markdown(
    f"""
    <div class="glass-card">
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Cost Line</th>
                    <th>Unit</th>
                    <th>Volume</th>
                    <th>Line Total (₹/mo)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Storage (Supabase free tier)</td>
                    <td>GB-month</td>
                    <td>{storage_gb:.3f} GB</td>
                    <td class="cost-zero">₹0 (free tier)</td>
                </tr>
                <tr>
                    <td>Compute (Streamlit Cloud / EC2)</td>
                    <td>per month</td>
                    <td>1 instance</td>
                    <td class="cost-paid">₹{hosting_cost:,.0f}</td>
                </tr>
                <tr>
                    <td>GPT-4o — Input tokens</td>
                    <td>₹{cost_per_1k_input:.2f} / 1K tokens</td>
                    <td>{total_input_tokens/1000:,.0f}K tokens</td>
                    <td class="cost-paid">₹{cloud_input_cost:,.2f}</td>
                </tr>
                <tr>
                    <td>GPT-4o — Output tokens</td>
                    <td>₹{cost_per_1k_output:.2f} / 1K tokens</td>
                    <td>{total_output_tokens/1000:,.0f}K tokens</td>
                    <td class="cost-paid">₹{cloud_output_cost:,.2f}</td>
                </tr>
                <tr>
                    <td>Dashboards (Streamlit Cloud)</td>
                    <td>per month</td>
                    <td>1 instance</td>
                    <td class="cost-zero">₹0 (free tier)</td>
                </tr>
                <tr>
                    <td>Data Egress (AWS standard)</td>
                    <td>GB-month</td>
                    <td>{storage_gb*0.1:.4f} GB</td>
                    <td class="cost-zero">₹0 (minimal)</td>
                </tr>
            </tbody>
        </table>
    </div>
    """,
    unsafe_allow_html=True,
)

col_c1, col_c2 = st.columns(2)

with col_c1:
    st.markdown(
        f"""
        <div class="glass-card" style="text-align:center; padding: 2rem;">
            <div class="big-number" style="background: linear-gradient(135deg, #F59E0B, #EF4444); -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent;">
                ₹{cloud_grand_total:,.0f} / mo
            </div>
            <div class="big-label">Cloud API Cost (GPT-4o)</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with col_c2:
    st.markdown(
        f"""
        <div class="glass-card" style="text-align:center; padding: 2rem;">
            <div class="big-number">₹{cloud_grand_total:,.0f}</div>
            <div class="big-label">Monthly Savings with Ollama</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ── Assumptions Table ───────────────────────────────────────────────────
st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="section-header">📐 Assumptions & Thresholds</div>', unsafe_allow_html=True)
st.markdown("")

st.markdown(
    f"""
    <div class="glass-card">
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Parameter</th>
                    <th>Value</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Meetings per month</td>
                    <td><strong>{meetings_per_month:,}</strong></td>
                    <td>Adjustable via slider</td>
                </tr>
                <tr>
                    <td>Avg words per transcript</td>
                    <td><strong>{avg_words_per_transcript:,}</strong></td>
                    <td>Adjustable via slider</td>
                </tr>
                <tr>
                    <td>Avg tokens per transcript</td>
                    <td><strong>~{avg_tokens:,}</strong></td>
                    <td>1.33 tokens/word heuristic</td>
                </tr>
                <tr>
                    <td>Avg output tokens per summary</td>
                    <td><strong>~800</strong></td>
                    <td>Typical structured summary</td>
                </tr>
                <tr>
                    <td>Active users</td>
                    <td><strong>{num_users}</strong></td>
                    <td>Adjustable via slider</td>
                </tr>
                <tr>
                    <td>Ollama model</td>
                    <td><strong>Llama 3.2 (3B)</strong></td>
                    <td>Free, local, zero API cost</td>
                </tr>
                <tr>
                    <td>Cloud alternative</td>
                    <td><strong>GPT-4o</strong></td>
                    <td>~$2.50/1M in, ~$10/1M out tokens</td>
                </tr>
                <tr>
                    <td>USD to INR</td>
                    <td><strong>₹{usd_to_inr}</strong></td>
                    <td>Approximate rate</td>
                </tr>
            </tbody>
        </table>
    </div>
    """,
    unsafe_allow_html=True,
)


# ── Free → Paid Thresholds ──────────────────────────────────────────────
st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="section-header">🔀 Free Tier → Paid Thresholds</div>', unsafe_allow_html=True)
st.markdown("")

st.markdown(
    """
    <div class="glass-card">
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Service</th>
                    <th>Free Tier</th>
                    <th>Trigger for Paid</th>
                    <th>Paid Cost</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Ollama (local)</td>
                    <td class="cost-zero">Always free</td>
                    <td>Never (runs on your hardware)</td>
                    <td class="cost-zero">₹0</td>
                </tr>
                <tr>
                    <td>Streamlit Community Cloud</td>
                    <td class="cost-zero">1 app, public</td>
                    <td>>100 users or private apps</td>
                    <td class="cost-paid">~₹2,100/mo</td>
                </tr>
                <tr>
                    <td>Supabase (if added)</td>
                    <td class="cost-zero">500 MB, 50K rows</td>
                    <td>>500 MB storage</td>
                    <td class="cost-paid">~₹2,100/mo</td>
                </tr>
                <tr>
                    <td>OpenAI GPT-4o</td>
                    <td class="cost-paid">No free tier</td>
                    <td>From first API call</td>
                    <td class="cost-paid">₹0.21/1K input tokens</td>
                </tr>
            </tbody>
        </table>
    </div>
    """,
    unsafe_allow_html=True,
)

# ── Key Insight ─────────────────────────────────────────────────────────
st.markdown("")
st.info(
    f"💡 **Key Insight**: By using Ollama (local LLM), the entire operating cost is **₹0/month**. "
    f"The only cost is hardware (≥8GB RAM machine). "
    f"A cloud alternative (GPT-4o) would cost **₹{cloud_grand_total:,.0f}/month** at {meetings_per_month} meetings/month."
)

# ── Footer ──────────────────────────────────────────────────────────────
st.markdown("")
st.markdown(
    '<div class="app-footer">'
    "MeetingMind · Deliverable B — Operating Budget · DBM 03"
    "</div>",
    unsafe_allow_html=True,
)
