"""
Shared CSS Styles
Centralised style definitions used across all MeetingMind pages.
Eliminates CSS duplication — change once, applied everywhere.
"""

import streamlit as st


def inject_global_css():
    """Inject the shared CSS that every page needs (fonts, backgrounds, sidebar, cards, etc.)."""
    st.markdown("""
<style>
    /* ─── Google Font Import ─── */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500&display=swap');

    /* ─── Animated Gradient Background ─── */
    .stApp {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }

    .stApp::before {
        content: '';
        position: fixed;
        top: 0; left: 0; right: 0; bottom: 0;
        background: 
            radial-gradient(ellipse at 20% 50%, rgba(108, 99, 255, 0.08) 0%, transparent 50%),
            radial-gradient(ellipse at 80% 20%, rgba(0, 212, 170, 0.06) 0%, transparent 50%),
            radial-gradient(ellipse at 60% 80%, rgba(118, 75, 162, 0.05) 0%, transparent 50%);
        animation: bgShift 15s ease-in-out infinite alternate;
        pointer-events: none;
        z-index: 0;
    }

    @keyframes bgShift {
        0% { opacity: 1; transform: scale(1); }
        50% { opacity: 0.8; transform: scale(1.05); }
        100% { opacity: 1; transform: scale(1); }
    }

    /* ─── Sidebar Styling ─── */
    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0D0F18 0%, #0A0C14 100%) !important;
        border-right: 1px solid rgba(108, 99, 255, 0.12) !important;
    }

    section[data-testid="stSidebar"] .stMarkdown h1 {
        background: linear-gradient(135deg, #6C63FF 0%, #00D4AA 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        font-weight: 800;
        font-size: 1.6rem;
        letter-spacing: -0.03em;
    }

    /* ─── Sidebar Nav Links ─── */
    section[data-testid="stSidebar"] a[data-testid="stSidebarNavLink"] {
        border-radius: 10px !important;
        padding: 0.5rem 0.8rem !important;
        margin: 2px 0 !important;
        transition: all 0.25s ease !important;
    }

    section[data-testid="stSidebar"] a[data-testid="stSidebarNavLink"]:hover {
        background: rgba(108, 99, 255, 0.12) !important;
        transform: translateX(3px);
    }

    section[data-testid="stSidebar"] a[data-testid="stSidebarNavLink"][aria-current="page"] {
        background: rgba(108, 99, 255, 0.15) !important;
        border-left: 3px solid #6C63FF !important;
    }

    /* ─── Glass Card Containers ─── */
    .glass-card {
        background: rgba(26, 29, 41, 0.7);
        backdrop-filter: blur(24px);
        -webkit-backdrop-filter: blur(24px);
        border: 1px solid rgba(108, 99, 255, 0.12);
        border-radius: 20px;
        padding: 1.8rem;
        margin-bottom: 1rem;
        transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
    }

    .glass-card::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(108, 99, 255, 0.4), transparent);
    }

    .glass-card:hover {
        border-color: rgba(108, 99, 255, 0.3);
        box-shadow: 0 8px 40px rgba(108, 99, 255, 0.12), 0 0 0 1px rgba(108, 99, 255, 0.1);
        transform: translateY(-3px);
    }

    /* ─── Page Header ─── */
    .page-header {
        font-size: 2.4rem;
        font-weight: 900;
        letter-spacing: -0.04em;
        background: linear-gradient(135deg, #6C63FF 0%, #00D4AA 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin-bottom: 0.3rem;
    }

    .page-subtitle {
        font-size: 1.05rem;
        color: #9CA3AF;
        margin-bottom: 1.5rem;
        line-height: 1.6;
    }

    /* ─── Section Headers ─── */
    .section-header {
        font-size: 1.3rem;
        font-weight: 700;
        color: #EAEAEA;
        letter-spacing: -0.02em;
        margin-bottom: 0.5rem;
    }

    /* ─── Gradient Divider ─── */
    .gradient-divider {
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(108, 99, 255, 0.3), rgba(0, 212, 170, 0.2), transparent);
        border: none;
        margin: 2rem 0;
    }

    /* ─── Status Badge ─── */
    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 0.4rem 1rem;
        border-radius: 100px;
        font-size: 0.8rem;
        font-weight: 600;
        letter-spacing: 0.01em;
    }

    .status-online {
        background: rgba(16, 185, 129, 0.12);
        color: #10B981;
        border: 1px solid rgba(16, 185, 129, 0.25);
    }

    .status-offline {
        background: rgba(239, 68, 68, 0.12);
        color: #EF4444;
        border: 1px solid rgba(239, 68, 68, 0.25);
    }

    /* ─── Big Numbers ─── */
    .big-number {
        font-size: 3rem;
        font-weight: 900;
        background: linear-gradient(135deg, #6C63FF, #00D4AA);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        text-align: center;
        letter-spacing: -0.03em;
    }

    .big-label {
        text-align: center;
        color: #6B7280;
        font-size: 0.85rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-top: 0.3rem;
    }

    /* ─── Styled Tables ─── */
    .styled-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        border-radius: 14px;
        overflow: hidden;
        font-size: 0.9rem;
    }

    .styled-table thead tr {
        background: linear-gradient(135deg, rgba(108, 99, 255, 0.15), rgba(0, 212, 170, 0.1));
    }

    .styled-table th {
        padding: 14px 16px;
        text-align: left;
        color: #EAEAEA;
        font-weight: 700;
        font-size: 0.82rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        border-bottom: 1px solid rgba(108, 99, 255, 0.15);
    }

    .styled-table td {
        padding: 12px 16px;
        color: #D1D5DB;
        border-bottom: 1px solid rgba(45, 51, 72, 0.4);
    }

    .styled-table tbody tr {
        transition: background 0.2s ease;
    }

    .styled-table tbody tr:hover {
        background: rgba(108, 99, 255, 0.06);
    }

    .styled-table tbody tr:nth-child(even) {
        background: rgba(26, 29, 41, 0.3);
    }

    .styled-table tbody tr:nth-child(even):hover {
        background: rgba(108, 99, 255, 0.08);
    }

    .styled-table tbody tr:last-child td {
        border-bottom: none;
    }

    .cost-zero {
        color: #10B981;
        font-weight: 700;
    }

    .cost-paid {
        color: #F59E0B;
        font-weight: 700;
    }

    /* ─── Metric Bar ─── */
    .metric-bar {
        display: flex;
        gap: 2rem;
        padding: 1rem 1.5rem;
        background: rgba(26, 29, 41, 0.5);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(108, 99, 255, 0.1);
        border-radius: 14px;
        margin: 1rem 0;
    }

    .metric-item {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        font-size: 0.85rem;
        color: #6B7280;
    }

    .metric-value {
        color: #EAEAEA;
        font-weight: 700;
    }

    /* ─── Result Header ─── */
    .result-header {
        font-size: 1.4rem;
        font-weight: 800;
        color: #EAEAEA;
        margin-bottom: 0.5rem;
        letter-spacing: -0.02em;
    }

    /* ─── Button Overrides ─── */
    .stButton > button {
        border-radius: 12px !important;
        font-weight: 600 !important;
        font-family: 'Inter', sans-serif !important;
        letter-spacing: -0.01em !important;
        transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1) !important;
        border: none !important;
    }

    .stButton > button[kind="primary"] {
        background: linear-gradient(135deg, #6C63FF, #5A52E0) !important;
        box-shadow: 0 4px 15px rgba(108, 99, 255, 0.3) !important;
    }

    .stButton > button[kind="primary"]:hover {
        transform: translateY(-2px) !important;
        box-shadow: 0 8px 25px rgba(108, 99, 255, 0.4) !important;
        background: linear-gradient(135deg, #7B73FF, #6C63FF) !important;
    }

    .stButton > button:hover {
        transform: translateY(-1px) !important;
        box-shadow: 0 4px 15px rgba(108, 99, 255, 0.2) !important;
    }

    /* ─── Download Buttons ─── */
    .stDownloadButton > button {
        border-radius: 12px !important;
        font-weight: 600 !important;
        font-family: 'Inter', sans-serif !important;
        transition: all 0.25s ease !important;
        background: rgba(108, 99, 255, 0.1) !important;
        border: 1px solid rgba(108, 99, 255, 0.25) !important;
        color: #8B83FF !important;
    }

    .stDownloadButton > button:hover {
        background: rgba(108, 99, 255, 0.2) !important;
        transform: translateY(-1px) !important;
        box-shadow: 0 4px 15px rgba(108, 99, 255, 0.15) !important;
    }

    /* ─── Text Area ─── */
    .stTextArea textarea {
        border-radius: 14px !important;
        border: 1px solid rgba(108, 99, 255, 0.15) !important;
        background: rgba(26, 29, 41, 0.5) !important;
        font-family: 'Inter', sans-serif !important;
        font-size: 0.9rem !important;
        line-height: 1.6 !important;
        transition: border-color 0.3s ease !important;
    }

    .stTextArea textarea:focus {
        border-color: rgba(108, 99, 255, 0.4) !important;
        box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.1) !important;
    }

    /* ─── Tabs ─── */
    .stTabs [data-baseweb="tab-list"] {
        gap: 0.5rem;
    }

    .stTabs [data-baseweb="tab"] {
        border-radius: 10px !important;
        padding: 0.5rem 1.2rem !important;
        font-weight: 600 !important;
    }

    /* ─── Expander ─── */
    .streamlit-expanderHeader {
        font-weight: 600 !important;
        font-size: 1rem !important;
        border-radius: 12px !important;
    }

    /* ─── Animation Keyframes ─── */
    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(25px); }
        to { opacity: 1; transform: translateY(0); }
    }

    .animate-in {
        animation: fadeInUp 0.7s cubic-bezier(0.4, 0, 0.2, 1) forwards;
    }

    .animate-in-delay-1 { animation-delay: 0.1s; opacity: 0; }
    .animate-in-delay-2 { animation-delay: 0.2s; opacity: 0; }
    .animate-in-delay-3 { animation-delay: 0.3s; opacity: 0; }
    .animate-in-delay-4 { animation-delay: 0.4s; opacity: 0; }

    /* ─── Footer ─── */
    .app-footer {
        text-align: center;
        color: #4B5563;
        font-size: 0.8rem;
        padding: 2rem 0 1rem 0;
        letter-spacing: 0.02em;
    }

    .app-footer a {
        color: #6C63FF;
        text-decoration: none;
    }
</style>
""", unsafe_allow_html=True)
