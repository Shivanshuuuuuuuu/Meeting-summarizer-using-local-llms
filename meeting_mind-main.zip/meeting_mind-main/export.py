"""
Export Utilities
Format summaries for download. All baked-in — template-based, no LLM needed.
"""

import re
from datetime import datetime


def to_markdown(summary: str, source_name: str = "Meeting Transcript") -> str:
    """
    Wrap the summary in a downloadable markdown document with metadata header.
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    header = f"""---
title: Meeting Summary
source: {source_name}
generated: {now}
tool: MeetingMind (Ollama Local LLM)
---

# Meeting Summary

> Generated on {now} from: *{source_name}*

---

"""
    return header + summary


def to_plain_text(summary: str, source_name: str = "Meeting Transcript") -> str:
    """
    Convert markdown summary to plain text for simpler export.
    Strips markdown formatting using regex patterns.
    """
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    header = f"""MEETING SUMMARY
{'='*60}
Source: {source_name}
Generated: {now}
Tool: MeetingMind (Ollama Local LLM)
{'='*60}

"""
    text = summary

    # Strip headers (## Header → HEADER)
    text = re.sub(r'^#{1,6}\s+(.+)$', lambda m: m.group(1).upper(), text, flags=re.MULTILINE)

    # Strip bold and italic (**bold**, *italic*, __bold__, _italic_)
    text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
    text = re.sub(r'__(.+?)__', r'\1', text)
    text = re.sub(r'\*(.+?)\*', r'\1', text)
    text = re.sub(r'_(.+?)_', r'\1', text)

    # Strip inline code
    text = re.sub(r'`(.+?)`', r'\1', text)

    # Strip links [text](url) → text
    text = re.sub(r'\[(.+?)\]\(.+?\)', r'\1', text)

    # Strip blockquotes
    text = re.sub(r'^>\s?', '', text, flags=re.MULTILINE)

    # Strip horizontal rules
    text = re.sub(r'^-{3,}$', '-' * 40, text, flags=re.MULTILINE)

    # Simplify markdown tables: remove | delimiters, align with spaces
    text = re.sub(r'\|', '  ', text)
    text = re.sub(r'^[\s-]+$', '', text, flags=re.MULTILINE)

    return header + text
