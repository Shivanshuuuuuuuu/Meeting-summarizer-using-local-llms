"""
Text Processing Utilities
Handles word counting, token estimation, and text chunking.
All of these are "baked-in" operations — no LLM needed at runtime.
"""


def count_words(text: str) -> int:
    """Count words in text."""
    return len(text.split())


def estimate_tokens(text: str) -> int:
    """
    Rough token estimate: ~1.33 tokens per word for English text.
    This is a baked-in heuristic — no API call needed.
    """
    return int(count_words(text) * 1.33)


def chunk_text(text: str, max_tokens: int = 3500) -> list[str]:
    """
    Split text into chunks if it exceeds max_tokens.
    Uses paragraph-level splitting to preserve context.
    
    Args:
        text: Input text
        max_tokens: Maximum tokens per chunk (default 3500 to leave room for prompt)
        
    Returns:
        List of text chunks
    """
    estimated = estimate_tokens(text)
    if estimated <= max_tokens:
        return [text]
    
    # Split by double newlines (paragraphs) first
    paragraphs = text.split("\n\n")
    if len(paragraphs) <= 1:
        # Fall back to single newlines
        paragraphs = text.split("\n")
    
    chunks = []
    current_chunk = []
    current_tokens = 0
    
    for para in paragraphs:
        para_tokens = estimate_tokens(para)
        if current_tokens + para_tokens > max_tokens and current_chunk:
            chunks.append("\n\n".join(current_chunk))
            current_chunk = [para]
            current_tokens = para_tokens
        else:
            current_chunk.append(para)
            current_tokens += para_tokens
    
    if current_chunk:
        chunks.append("\n\n".join(current_chunk))
    
    return chunks


def validate_input(text: str) -> tuple[bool, str]:
    """
    Validate that input text is suitable for summarization.
    
    Returns:
        (is_valid, message) tuple
    """
    if not text or not text.strip():
        return False, "Please provide some meeting text to summarize."
    
    word_count = count_words(text)
    
    if word_count < 20:
        return False, f"Input is too short ({word_count} words). Please provide a more detailed transcript."
    
    if word_count > 50000:
        return False, f"Input is very long ({word_count} words). Please keep it under 50,000 words."
    
    return True, f"✅ Ready to process — {word_count} words (~{estimate_tokens(text)} tokens)"
