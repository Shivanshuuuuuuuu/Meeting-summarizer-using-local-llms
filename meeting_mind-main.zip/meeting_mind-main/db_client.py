"""
MongoDB Client Wrapper
Handles all communication with the local MongoDB server.
Stores meeting summaries, user feedback, and usage analytics.

Collections:
  - summaries : transcript + summary + metadata per meeting
  - feedback  : 1-5 star ratings and comments linked to a summary
  - analytics : event log for usage tracking (summarize, export, page_view)
"""

from datetime import datetime, timezone
from bson import ObjectId
import streamlit as st

# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------

MONGO_URI = "mongodb://localhost:27017"
DB_NAME = "meetingmind_db"


def _get_client():
    """Return a cached pymongo MongoClient (one per Streamlit session)."""
    from pymongo import MongoClient
    if "mongo_client" not in st.session_state:
        st.session_state["mongo_client"] = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
    return st.session_state["mongo_client"]


def get_db():
    """Return the meetingmind_db database handle."""
    return _get_client()[DB_NAME]


@st.cache_data(ttl=30, show_spinner=False)
def check_mongo_connection():
    """Check if MongoDB server is running and reachable. Cached for 30s."""
    try:
        from pymongo import MongoClient
        client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
        client.admin.command("ping")
        return True, "Connected"
    except Exception as e:
        return False, str(e)


# ---------------------------------------------------------------------------
# Summaries CRUD
# ---------------------------------------------------------------------------

def save_summary(
    transcript: str,
    summary: str,
    model: str,
    source: str,
    elapsed: float,
    word_count: int,
    token_count: int,
) -> str:
    """
    Save a meeting summary document to MongoDB.

    Returns:
        The inserted document's ObjectId as a string.
    """
    doc = {
        "transcript": transcript,
        "summary": summary,
        "model": model,
        "source": source,
        "elapsed_seconds": round(elapsed, 2),
        "word_count": word_count,
        "token_count": token_count,
        "created_at": datetime.now(timezone.utc),
    }
    result = get_db()["summaries"].insert_one(doc)
    return str(result.inserted_id)


def get_all_summaries(limit: int = 50) -> list[dict]:
    """
    Retrieve all past summaries, newest first.

    Returns:
        List of summary documents (with '_id' converted to string 'id').
    """
    cursor = get_db()["summaries"].find().sort("created_at", -1).limit(limit)
    docs = []
    for doc in cursor:
        doc["id"] = str(doc.pop("_id"))
        docs.append(doc)
    return docs


def get_summary_by_id(doc_id: str) -> dict | None:
    """Retrieve a single summary by its ObjectId string."""
    doc = get_db()["summaries"].find_one({"_id": ObjectId(doc_id)})
    if doc:
        doc["id"] = str(doc.pop("_id"))
    return doc


def delete_summary(doc_id: str) -> bool:
    """
    Delete a summary and its associated feedback.

    Returns:
        True if the summary was deleted, False otherwise.
    """
    db = get_db()
    # Delete associated feedback
    db["feedback"].delete_many({"summary_id": doc_id})
    result = db["summaries"].delete_one({"_id": ObjectId(doc_id)})
    return result.deleted_count > 0


# ---------------------------------------------------------------------------
# Feedback
# ---------------------------------------------------------------------------

def save_feedback(summary_id: str, rating: int, comment: str = "") -> str:
    """
    Save a feedback entry for a summary.

    Args:
        summary_id: The summary's ObjectId string.
        rating: 1-5 star rating.
        comment: Optional text comment.

    Returns:
        The inserted feedback document's ObjectId as a string.
    """
    doc = {
        "summary_id": summary_id,
        "rating": max(1, min(5, rating)),
        "comment": comment.strip(),
        "created_at": datetime.now(timezone.utc),
    }
    result = get_db()["feedback"].insert_one(doc)
    return str(result.inserted_id)


def get_feedback_for_summary(summary_id: str) -> list[dict]:
    """Retrieve all feedback entries for a given summary."""
    cursor = get_db()["feedback"].find({"summary_id": summary_id}).sort("created_at", -1)
    docs = []
    for doc in cursor:
        doc["id"] = str(doc.pop("_id"))
        docs.append(doc)
    return docs


# ---------------------------------------------------------------------------
# Analytics / Usage Logging
# ---------------------------------------------------------------------------

def log_usage(event_type: str, metadata: dict | None = None):
    """
    Log a usage event.

    Args:
        event_type: One of 'summarize', 'export', 'page_view', etc.
        metadata: Optional dict with extra info (model, tokens, etc.)
    """
    doc = {
        "event_type": event_type,
        "metadata": metadata or {},
        "created_at": datetime.now(timezone.utc),
    }
    get_db()["analytics"].insert_one(doc)


def get_usage_stats() -> dict:
    """
    Aggregate usage statistics from the analytics and summaries collections.

    Returns:
        Dict with total_summaries, total_tokens, avg_processing_time,
        summaries_by_day, model_usage, total_exports, total_feedback.
    """
    db = get_db()

    # ── Summary stats ──
    total_summaries = db["summaries"].count_documents({})

    pipeline_tokens = [
        {"$group": {"_id": None, "total": {"$sum": "$token_count"}, "avg_time": {"$avg": "$elapsed_seconds"}}}
    ]
    agg = list(db["summaries"].aggregate(pipeline_tokens))
    total_tokens = agg[0]["total"] if agg else 0
    avg_time = round(agg[0]["avg_time"], 2) if agg else 0

    # ── Summaries by day (last 30 days) ──
    pipeline_daily = [
        {
            "$group": {
                "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                "count": {"$sum": 1},
            }
        },
        {"$sort": {"_id": 1}},
        {"$limit": 30},
    ]
    daily = {doc["_id"]: doc["count"] for doc in db["summaries"].aggregate(pipeline_daily)}

    # ── Model usage ──
    pipeline_models = [
        {"$group": {"_id": "$model", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
    ]
    model_usage = {doc["_id"]: doc["count"] for doc in db["summaries"].aggregate(pipeline_models)}

    # ── Export count ──
    total_exports = db["analytics"].count_documents({"event_type": "export"})

    # ── Feedback count ──
    total_feedback = db["feedback"].count_documents({})

    # ── Average rating ──
    pipeline_rating = [{"$group": {"_id": None, "avg": {"$avg": "$rating"}}}]
    rating_agg = list(db["feedback"].aggregate(pipeline_rating))
    avg_rating = round(rating_agg[0]["avg"], 1) if rating_agg else 0

    return {
        "total_summaries": total_summaries,
        "total_tokens": total_tokens,
        "avg_processing_time": avg_time,
        "summaries_by_day": daily,
        "model_usage": model_usage,
        "total_exports": total_exports,
        "total_feedback": total_feedback,
        "avg_rating": avg_rating,
    }
