"""
MeetingMind — Meeting Notes & Transcript Summarizer
====================================================
A data product that turns a wall of meeting text into structured
decisions, action items, and summaries using Ollama (free local LLM).

Built with Streamlit | Powered by Ollama + Llama 3.2
DBM 03 — Big Data for Digital Transformation
"""

import streamlit as st
import requests
from streamlit_lottie import st_lottie

# ── Page Configuration ──────────────────────────────────────────────────
st.set_page_config(
    page_title="MeetingMind — Smart Meeting Summarizer",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ── Lottie Animation Loader ────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def load_lottie_url(url: str):
    try:
        r = requests.get(url, timeout=5)
        if r.status_code != 200:
            return None
        return r.json()
    except Exception:
        return None


# ── Shared Styles & Sidebar ─────────────────────────────────────────────
from utils.styles import inject_global_css
from utils.sidebar import render_sidebar

inject_global_css()

# Homepage-specific CSS (hero, stat cards, steps, feature pills)
st.markdown("""
<style>
    /* ─── Hero Section ─── */
    .hero-container {
        padding: 2rem 0 1rem 0;
    }

    .hero-title {
        font-size: 3.5rem;
        font-weight: 900;
        letter-spacing: -0.04em;
        line-height: 1.05;
        margin-bottom: 0.6rem;
        background: linear-gradient(135deg, #6C63FF 0%, #8B83FF 30%, #00D4AA 70%, #33DDBB 100%);
        background-size: 200% auto;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        animation: shimmer 4s ease-in-out infinite alternate;
    }

    @keyframes shimmer {
        0% { background-position: 0% center; }
        100% { background-position: 100% center; }
    }

    .hero-subtitle {
        font-size: 1.15rem;
        color: #9CA3AF;
        font-weight: 400;
        line-height: 1.7;
        max-width: 650px;
    }

    .hero-subtitle strong {
        color: #EAEAEA;
    }

    /* ─── Stat Cards ─── */
    .stat-card {
        background: rgba(26, 29, 41, 0.6);
        border: 1px solid rgba(108, 99, 255, 0.1);
        border-radius: 16px;
        padding: 1.5rem 1.2rem;
        text-align: center;
        transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
    }

    .stat-card::after {
        content: '';
        position: absolute;
        bottom: 0; left: 0; right: 0;
        height: 2px;
        background: linear-gradient(90deg, #6C63FF, #00D4AA);
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .stat-card:hover {
        border-color: rgba(108, 99, 255, 0.25);
        box-shadow: 0 8px 30px rgba(108, 99, 255, 0.1);
        transform: translateY(-4px);
    }

    .stat-card:hover::after {
        opacity: 1;
    }

    .stat-icon {
        font-size: 2.2rem;
        margin-bottom: 0.3rem;
    }

    .stat-number {
        font-size: 1.4rem;
        font-weight: 800;
        background: linear-gradient(135deg, #6C63FF, #00D4AA);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        letter-spacing: -0.02em;
    }

    .stat-label {
        font-size: 0.78rem;
        color: #6B7280;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        margin-top: 0.3rem;
    }

    /* ─── Feature Pills ─── */
    .feature-pill {
        display: inline-block;
        background: rgba(108, 99, 255, 0.08);
        border: 1px solid rgba(108, 99, 255, 0.18);
        border-radius: 100px;
        padding: 0.45rem 1.1rem;
        font-size: 0.82rem;
        color: #8B83FF;
        font-weight: 500;
        margin: 0.25rem;
        transition: all 0.25s ease;
        cursor: default;
    }

    .feature-pill:hover {
        background: rgba(108, 99, 255, 0.18);
        border-color: rgba(108, 99, 255, 0.35);
        transform: translateY(-2px) scale(1.03);
        box-shadow: 0 4px 15px rgba(108, 99, 255, 0.15);
    }

    /* ─── Step Cards ─── */
    .step-card {
        background: rgba(26, 29, 41, 0.5);
        border: 1px solid rgba(108, 99, 255, 0.08);
        border-radius: 20px;
        padding: 2rem 1.5rem;
        transition: all 0.35s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        height: 100%;
    }

    .step-card:hover {
        border-color: rgba(108, 99, 255, 0.25);
        background: rgba(26, 29, 41, 0.7);
        box-shadow: 0 8px 30px rgba(108, 99, 255, 0.08);
        transform: translateY(-4px);
    }

    .step-number {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        width: 36px;
        height: 36px;
        border-radius: 10px;
        background: linear-gradient(135deg, rgba(108, 99, 255, 0.2), rgba(0, 212, 170, 0.15));
        border: 1px solid rgba(108, 99, 255, 0.3);
        font-size: 0.85rem;
        font-weight: 700;
        color: #8B83FF;
        margin-bottom: 1rem;
    }

    .step-title {
        font-size: 1.1rem;
        font-weight: 700;
        color: #EAEAEA;
        margin-bottom: 0.5rem;
    }

    .step-desc {
        font-size: 0.9rem;
        color: #9CA3AF;
        line-height: 1.6;
    }
</style>
""", unsafe_allow_html=True)


# ── Sidebar ─────────────────────────────────────────────────────────────
render_sidebar(show_connection=True)



# ── Hero Section ────────────────────────────────────────────────────────
hero_col, lottie_col = st.columns([3, 2])

with hero_col:
    st.markdown(
        """
        <div class="hero-container animate-in">
            <div class="hero-title">MeetingMind</div>
            <div class="hero-subtitle">
                Turn walls of meeting text into <strong>crystal-clear decisions</strong> and 
                <strong>action items</strong>. Powered by a local LLM — 
                your data never leaves your machine.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with lottie_col:
    lottie_data = load_lottie_url(
        "https://assets5.lottiefiles.com/packages/lf20_fcfjwiyb.json"
    )
    if lottie_data:
        st_lottie(lottie_data, height=250, key="hero_lottie")
    else:
        # Fallback if Lottie fails to load
        st.markdown(
            """
            <div style="display:flex; align-items:center; justify-content:center; height:250px; font-size:6rem;">
                🧠
            </div>
            """,
            unsafe_allow_html=True,
        )

st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)

# ── Stats Bar ───────────────────────────────────────────────────────────
col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown(
        """
        <div class="stat-card animate-in animate-in-delay-1">
            <div class="stat-icon">🔒</div>
            <div class="stat-number">Private</div>
            <div class="stat-label">100% Local Processing</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with col2:
    st.markdown(
        """
        <div class="stat-card animate-in animate-in-delay-2">
            <div class="stat-icon">💰</div>
            <div class="stat-number">₹0</div>
            <div class="stat-label">Zero API Cost</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with col3:
    st.markdown(
        """
        <div class="stat-card animate-in animate-in-delay-3">
            <div class="stat-icon">⚡</div>
            <div class="stat-number">Real-Time</div>
            <div class="stat-label">Streaming Output</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with col4:
    st.markdown(
        """
        <div class="stat-card animate-in animate-in-delay-4">
            <div class="stat-icon">📋</div>
            <div class="stat-number">Structured</div>
            <div class="stat-label">Decisions & Actions</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)

# ── How It Works ────────────────────────────────────────────────────────
st.markdown('<div class="section-header">How It Works</div>', unsafe_allow_html=True)
st.markdown("")

col_a, col_b, col_c = st.columns(3)

with col_a:
    st.markdown(
        """
        <div class="step-card animate-in animate-in-delay-1">
            <div class="step-number">01</div>
            <div class="step-title">Paste or Upload</div>
            <div class="step-desc">
                Drop in your meeting transcript, raw notes, or upload a text file. 
                Works with any format — messy notes, Zoom transcripts, you name it.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with col_b:
    st.markdown(
        """
        <div class="step-card animate-in animate-in-delay-2">
            <div class="step-number">02</div>
            <div class="step-title">AI Analyzes</div>
            <div class="step-desc">
                Ollama's local LLM reads the full transcript and extracts 
                structure from the chaos — no cloud, no API key, no data leaks.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with col_c:
    st.markdown(
        """
        <div class="step-card animate-in animate-in-delay-3">
            <div class="step-number">03</div>
            <div class="step-title">Get Results</div>
            <div class="step-desc">
                Receive a clean summary with decisions, action items (with owners 
                & deadlines), discussion points, and open questions.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)

# ── Features ────────────────────────────────────────────────────────────
st.markdown('<div class="section-header">Features</div>', unsafe_allow_html=True)
st.markdown("")

features = [
    "Executive Summary", "Decision Extraction", "Action Items with Owners",
    "Priority Tagging", "Deadline Detection", "Discussion Points",
    "Open Questions", "Export to Markdown", "Sample Transcript",
    "Streaming Output", "Multi-Model Support", "Zero Cost Operation",
]

feature_html = " ".join(
    f'<span class="feature-pill">{f}</span>' for f in features
)
st.markdown(f'<div class="animate-in">{feature_html}</div>', unsafe_allow_html=True)

st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)

# ── API-in-the-Loop Explainer ───────────────────────────────────────────
st.markdown(
    '<div class="section-header">🔄 API-in-the-Loop vs. Baked-In Intelligence</div>',
    unsafe_allow_html=True,
)
st.markdown("")

st.markdown(
    """
    <div class="glass-card animate-in">
        <p style="color: #EAEAEA; font-size: 0.95rem; line-height: 1.8; margin:0;">
            <strong style="color: #8B83FF; font-size: 1.05rem;">Why does this product use a runtime LLM call?</strong><br><br>
            Most data products should <em>bake in</em> their intelligence — pre-compute during the build phase. 
            But meeting summarization is the <strong>counter-example</strong>: the input is genuinely unstructured 
            and unpredictable. You can't pre-compute a summary of a meeting that hasn't happened yet.<br><br>
            <span style="display:inline-flex; align-items:center; gap:6px; background:rgba(0,212,170,0.1); border:1px solid rgba(0,212,170,0.2); border-radius:8px; padding:2px 10px; margin-right:4px;">
                <span style="color:#00D4AA; font-weight:700;">Baked in</span>
            </span>
            System prompt, UI layout, export templates, cost calculations — these never change at runtime.<br><br>
            <span style="display:inline-flex; align-items:center; gap:6px; background:rgba(245,158,11,0.1); border:1px solid rgba(245,158,11,0.2); border-radius:8px; padding:2px 10px; margin-right:4px;">
                <span style="color:#F59E0B; font-weight:700;">API-in-the-loop</span>
            </span>
            The summarization call to Ollama — this <em>must</em> run at runtime because each transcript is unique.
        </p>
    </div>
    """,
    unsafe_allow_html=True,
)

# ── Footer ──────────────────────────────────────────────────────────────
st.markdown("")
st.markdown(
    '<div class="app-footer">'
    "MeetingMind · Built with Streamlit & Ollama · DBM 03 — Big Data for Digital Transformation · 2026"
    "</div>",
    unsafe_allow_html=True,
)
