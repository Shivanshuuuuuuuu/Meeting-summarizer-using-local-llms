"""
🏷️ Pricing Page — Deliverable C
=================================
Customer-facing pricing derived from the operating budget (Deliverable B).
Tiered pricing model with margin analysis.
"""

import os
import sys
import streamlit as st
import pandas as pd

st.set_page_config(
    page_title="Pricing — MeetingMind",
    page_icon="🏷️",
    layout="wide",
)

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

# ── Shared Styles & Sidebar ─────────────────────────────────────────────
from utils.styles import inject_global_css
from utils.sidebar import render_sidebar

inject_global_css()
render_sidebar(
    show_connection=False,
    badge_label="Deliverable C",
    badge_detail="Customer-facing pricing<br>derived from operating budget",
)

# Pricing-page-specific CSS
st.markdown("""
<style>
    /* ─── Pricing Grid ─── */
    .pricing-grid {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        gap: 1.5rem;
        align-items: stretch;
    }

    .pricing-card {
        background: rgba(26, 29, 41, 0.7);
        backdrop-filter: blur(24px);
        border: 1px solid rgba(108, 99, 255, 0.1);
        border-radius: 24px;
        padding: 2.5rem 2rem;
        text-align: center;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
        overflow: hidden;
        display: flex;
        flex-direction: column;
    }

    .pricing-card::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 1px;
        background: linear-gradient(90deg, transparent, rgba(108, 99, 255, 0.3), transparent);
    }

    .pricing-card:hover {
        border-color: rgba(108, 99, 255, 0.3);
        box-shadow: 0 12px 50px rgba(108, 99, 255, 0.12);
        transform: translateY(-6px);
    }

    .pricing-card.featured {
        border: 2px solid rgba(108, 99, 255, 0.5);
        box-shadow: 0 8px 40px rgba(108, 99, 255, 0.15);
        background: rgba(26, 29, 41, 0.85);
    }

    .pricing-card.featured::before {
        height: 2px;
        background: linear-gradient(90deg, #6C63FF, #00D4AA);
    }

    .pricing-card.featured:hover {
        box-shadow: 0 16px 60px rgba(108, 99, 255, 0.2);
        transform: translateY(-8px);
    }

    .popular-badge {
        background: linear-gradient(135deg, #6C63FF, #00D4AA);
        color: white;
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        padding: 0.35rem 1.2rem;
        border-radius: 100px;
        display: inline-block;
        margin-bottom: 0.8rem;
    }

    .pricing-tier {
        font-size: 0.8rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.12em;
        color: #6C63FF;
        margin-bottom: 0.5rem;
    }

    .pricing-price {
        font-size: 3rem;
        font-weight: 900;
        color: #EAEAEA;
        line-height: 1;
        margin: 0.3rem 0;
        letter-spacing: -0.03em;
    }

    .pricing-period {
        font-size: 0.85rem;
        color: #6B7280;
        margin-bottom: 1.8rem;
    }

    .pricing-features {
        flex-grow: 1;
        text-align: left;
    }

    .pricing-feature {
        padding: 0.55rem 0;
        color: #D1D5DB;
        font-size: 0.88rem;
        border-bottom: 1px solid rgba(45, 51, 72, 0.3);
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .pricing-feature:last-child {
        border-bottom: none;
    }

    .feat-yes { color: #10B981; }
    .feat-no { color: #4B5563; }
</style>
""", unsafe_allow_html=True)



# ── Page Header ─────────────────────────────────────────────────────────
st.markdown('<div class="page-header">🏷️ Customer Pricing</div>', unsafe_allow_html=True)
st.markdown(
    '<div class="page-subtitle">'
    "Pricing structure derived from our operating budget. "
    "Tiered model to serve individuals, teams, and enterprises."
    "</div>",
    unsafe_allow_html=True,
)
st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)


# ── Pricing Strategy ──────────────────────────────────────────────────
st.markdown('<div class="section-header">🎯 Pricing Strategy</div>', unsafe_allow_html=True)
st.markdown("")

st.markdown(
    """
    <div class="glass-card">
        <p style="color: #EAEAEA; font-size: 0.95rem; line-height: 1.8; margin:0;">
            <strong style="color: #8B83FF; font-size: 1.1rem;">Chosen Structure: Tiered (Free / Pro / Enterprise)</strong><br><br>
            <span style="color:#00D4AA;">✅</span> <strong>Low barrier</strong> — Free tier lets users try with zero risk<br>
            <span style="color:#00D4AA;">✅</span> <strong>Natural upgrade</strong> — Teams grow into higher tiers organically<br>
            <span style="color:#00D4AA;">✅</span> <strong>Predictable revenue</strong> — Per-seat monthly billing = stable income<br>
            <span style="color:#00D4AA;">✅</span> <strong>Low cost base</strong> — Ollama local = near ₹0 marginal cost per user<br><br>
            <span style="color:#6B7280;">Why not usage-based? Meeting volume is unpredictable; users prefer predictable bills.</span>
        </p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)


# ── Pricing Cards (CSS Grid — equal height) ────────────────────────────
st.markdown('<div class="section-header">💎 Pricing Plans</div>', unsafe_allow_html=True)
st.markdown("")

st.markdown(
    """
<div class="pricing-grid animate-in">
<div class="pricing-card">
    <div class="pricing-tier">Free</div>
    <div class="pricing-price">₹0</div>
    <div class="pricing-period">forever</div>
    <div class="pricing-features">
        <div class="pricing-feature"><span class="feat-yes">✓</span> 20 summaries / month</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Paste text input</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Basic structured summary</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Download as TXT</div>
        <div class="pricing-feature"><span class="feat-no">✗</span> <span style="color:#4B5563;">File upload</span></div>
        <div class="pricing-feature"><span class="feat-no">✗</span> <span style="color:#4B5563;">Priority processing</span></div>
        <div class="pricing-feature"><span class="feat-no">✗</span> <span style="color:#4B5563;">Custom prompts</span></div>
        <div class="pricing-feature"><span class="feat-no">✗</span> <span style="color:#4B5563;">Team workspace</span></div>
    </div>
</div>

<div class="pricing-card featured">
    <div class="popular-badge">Most Popular</div>
    <div class="pricing-tier">Pro</div>
    <div class="pricing-price">₹499</div>
    <div class="pricing-period">per user / month</div>
    <div class="pricing-features">
        <div class="pricing-feature"><span class="feat-yes">✓</span> Unlimited summaries</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Paste + File upload</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Full structured summary</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Download MD + TXT</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Priority processing</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Custom prompt templates</div>
        <div class="pricing-feature"><span class="feat-no">✗</span> <span style="color:#4B5563;">Team workspace</span></div>
        <div class="pricing-feature"><span class="feat-no">✗</span> <span style="color:#4B5563;">Admin dashboard</span></div>
    </div>
</div>

<div class="pricing-card">
    <div class="pricing-tier">Enterprise</div>
    <div class="pricing-price">₹1,499</div>
    <div class="pricing-period">per user / month</div>
    <div class="pricing-features">
        <div class="pricing-feature"><span class="feat-yes">✓</span> Everything in Pro</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Team workspace</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Admin dashboard</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> SSO integration</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> API access</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Custom model fine-tuning</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> Dedicated support</div>
        <div class="pricing-feature"><span class="feat-yes">✓</span> On-premise deployment</div>
    </div>
</div>
</div>
    """,
    unsafe_allow_html=True,
)

st.markdown("")

# Annual discount toggle
annual = st.toggle("Show annual pricing (15% discount)", value=False)

if annual:
    st.markdown(
        """
        <div class="glass-card" style="text-align:center; padding: 1.2rem;">
            <p style="color: #EAEAEA; font-size: 1rem; margin:0;">
                🎉 Annual pricing: 
                <strong>Free</strong> = ₹0 &nbsp;·&nbsp;
                <strong>Pro</strong> = ₹5,090/user/year <span style="color:#10B981;">(save ₹898)</span> &nbsp;·&nbsp;
                <strong>Enterprise</strong> = ₹15,290/user/year <span style="color:#10B981;">(save ₹2,698)</span>
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ── Margin Analysis ───────────────────────────────────────────────────
st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="section-header">📊 Margin Analysis</div>', unsafe_allow_html=True)
st.markdown("Interactive calculator — adjust paying users per tier.")
st.markdown("")

col_a, col_b = st.columns(2)
with col_a:
    pro_users = st.number_input("Pro users", min_value=0, max_value=10000, value=30, step=5)
with col_b:
    enterprise_users = st.number_input("Enterprise users", min_value=0, max_value=10000, value=10, step=5)

# Revenue
pro_revenue = pro_users * 499
enterprise_revenue = enterprise_users * 1499
total_revenue = pro_revenue + enterprise_revenue

# Cost
total_users = pro_users + enterprise_users
infra_cost = 0 if total_users <= 100 else 2100 + (total_users - 100) * 5
support_cost = enterprise_users * 100
total_cost = infra_cost + support_cost

margin = total_revenue - total_cost
margin_pct = (margin / total_revenue * 100) if total_revenue > 0 else 0

st.markdown("")

st.markdown(
    f"""
    <div class="glass-card">
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Line Item</th>
                    <th>Calculation</th>
                    <th>Amount (₹/mo)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Pro Revenue</td>
                    <td>{pro_users} users × ₹499</td>
                    <td style="color:#10B981; font-weight:700;">₹{pro_revenue:,}</td>
                </tr>
                <tr>
                    <td>Enterprise Revenue</td>
                    <td>{enterprise_users} users × ₹1,499</td>
                    <td style="color:#10B981; font-weight:700;">₹{enterprise_revenue:,}</td>
                </tr>
                <tr style="border-top: 2px solid rgba(108,99,255,0.2);">
                    <td><strong>Total Revenue</strong></td>
                    <td>Pro + Enterprise</td>
                    <td style="color:#EAEAEA; font-weight:800;">₹{total_revenue:,}</td>
                </tr>
                <tr>
                    <td>Infrastructure Cost</td>
                    <td>{"₹0 (within free tier)" if total_users <= 100 else "Hosting (scaled)"}</td>
                    <td style="color:#F59E0B; font-weight:700;">₹{infra_cost:,}</td>
                </tr>
                <tr>
                    <td>Support Cost</td>
                    <td>{enterprise_users} × ₹100</td>
                    <td style="color:#F59E0B; font-weight:700;">₹{support_cost:,}</td>
                </tr>
                <tr style="border-top: 2px solid rgba(108,99,255,0.2);">
                    <td><strong>Gross Margin</strong></td>
                    <td>Revenue − Cost</td>
                    <td style="color:#EAEAEA; font-weight:800;">₹{margin:,}</td>
                </tr>
            </tbody>
        </table>
    </div>
    """,
    unsafe_allow_html=True,
)

# Margin highlight cards
col_m1, col_m2, col_m3 = st.columns(3)

with col_m1:
    st.markdown(
        f"""
        <div class="glass-card" style="text-align:center; padding: 1.5rem;">
            <div class="big-number" style="font-size:2.2rem;">₹{total_revenue:,}</div>
            <div class="big-label">Monthly Revenue</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with col_m2:
    st.markdown(
        f"""
        <div class="glass-card" style="text-align:center; padding: 1.5rem;">
            <div class="big-number" style="font-size:2.2rem; background: linear-gradient(135deg, #F59E0B, #EF4444); -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent;">₹{total_cost:,}</div>
            <div class="big-label">Monthly Cost</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

with col_m3:
    margin_color = "#10B981" if margin_pct > 50 else "#F59E0B" if margin_pct > 20 else "#EF4444"
    st.markdown(
        f"""
        <div class="glass-card" style="text-align:center; padding: 1.5rem;">
            <div class="big-number" style="font-size:2.2rem; background:{margin_color}; -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent;">
                {margin_pct:.0f}%
            </div>
            <div class="big-label">Gross Margin</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ── API-in-the-loop cost impact ────────────────────────────────────────
st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="section-header">🔄 API-in-the-Loop Cost Impact</div>', unsafe_allow_html=True)
st.markdown("")

st.markdown(
    """
    <div class="glass-card">
        <p style="color: #EAEAEA; font-size: 0.95rem; line-height: 1.8; margin:0;">
            <strong style="color: #8B83FF;">With Ollama (current):</strong> 
            <span style="color:#10B981; font-weight:700;">₹0</span> per summarization call. 
            The LLM runs locally — marginal cost is effectively zero.<br><br>
            <strong style="color: #F59E0B;">With Cloud API (GPT-4o):</strong> 
            ~₹3.50 per call (2,000-word transcript). At 200 meetings/month = ₹700/month eating into margin.<br><br>
            <strong style="color: #00D4AA;">This is why we chose Ollama:</strong> It makes the API-in-the-loop 
            feature <em>free</em>, enabling high-margin pricing even at ₹499/month.
        </p>
    </div>
    """,
    unsafe_allow_html=True,
)


# ── Baked-in intelligence ──────────────────────────────────────────────
st.markdown('<div class="gradient-divider"></div>', unsafe_allow_html=True)
st.markdown('<div class="section-header">🧠 Where We Moved Intelligence Out of the Loop</div>', unsafe_allow_html=True)
st.markdown("")

baked_items = [
    ("System Prompt", "Same template for every request — hand-crafted, deterministic, no LLM needed to generate it."),
    ("Input Validation", "Word count, token estimation, format checking — all done with Python heuristics, not an LLM."),
    ("Export Formatting", "Converting summary to Markdown/TXT uses string templates — saves one API call per export."),
    ("Cost Calculations", "All pricing and budget math is deterministic Python. Zero intelligence needed at runtime."),
]

for title, desc in baked_items:
    st.markdown(
        f"""
        <div class="glass-card" style="padding: 1.2rem 1.5rem; margin-bottom: 0.6rem;">
            <p style="margin:0; color:#EAEAEA; font-size:0.92rem;">
                <span style="color:#10B981; font-weight:700;">✓ {title}</span>
                <span style="color:#9CA3AF;"> — {desc}</span>
            </p>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ── Footer ──────────────────────────────────────────────────────────────
st.markdown("")
st.markdown(
    '<div class="app-footer">'
    "MeetingMind · Deliverable C — Customer Pricing · DBM 03"
    "</div>",
    unsafe_allow_html=True,
)
