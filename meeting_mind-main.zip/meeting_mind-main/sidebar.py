"""
Shared Sidebar Component
Renders the consistent sidebar across all MeetingMind pages.
"""

import streamlit as st
from utils.ollama_client import check_connection
from utils.db_client import check_mongo_connection


def render_sidebar(*, show_connection: bool = True, badge_label: str | None = None, badge_detail: str | None = None):
    """
    Render the shared MeetingMind sidebar.

    Args:
        show_connection: If True, show the live Ollama connection status.
        badge_label: Optional label for a status badge (e.g., "Deliverable B").
        badge_detail: Optional detail text below the badge.

    Returns:
        (connected, selected_model) tuple if show_connection is True, else (None, None).
    """
    connected = None
    selected_model = None

    with st.sidebar:
        st.markdown("# 🧠 MeetingMind")
        st.markdown('<div class="gradient-divider" style="margin: 1rem 0;"></div>', unsafe_allow_html=True)

        if show_connection:
            connected, msg = check_connection()
            if connected:
                st.markdown(
                    '<span class="status-badge status-online">● Ollama Connected</span>',
                    unsafe_allow_html=True,
                )
            else:
                st.markdown(
                    '<span class="status-badge status-offline">● Ollama Offline</span>',
                    unsafe_allow_html=True,
                )
                st.error("Start Ollama to use MeetingMind")

        # MongoDB connection status
        mongo_ok, mongo_msg = check_mongo_connection()
        if mongo_ok:
            st.markdown(
                '<span class="status-badge status-online">● MongoDB Connected</span>',
                unsafe_allow_html=True,
            )
        else:
            st.markdown(
                '<span class="status-badge status-offline">● MongoDB Offline</span>',
                unsafe_allow_html=True,
            )

        if badge_label:
            st.markdown(
                f'<span class="status-badge status-online">● {badge_label}</span>',
                unsafe_allow_html=True,
            )

        st.markdown("")
        st.markdown("---")
        st.markdown(
            """
            <div style="color: #6B7280; font-size: 0.78rem; line-height: 1.6;">
            <strong style="color: #9CA3AF;">Tech Stack</strong><br>
            Streamlit · Ollama · Llama 3.2 · MongoDB<br><br>
            <strong style="color: #9CA3AF;">Course</strong><br>
            DBM 03 — Big Data for<br>Digital Transformation
            </div>
            """,
            unsafe_allow_html=True,
        )

        if badge_detail:
            st.markdown(
                f"""
                <div style="color: #6B7280; font-size: 0.78rem; line-height: 1.6; margin-top: 0.5rem;">
                <strong style="color: #9CA3AF;">{badge_label}</strong><br>
                {badge_detail}
                </div>
                """,
                unsafe_allow_html=True,
            )

    return connected, selected_model

